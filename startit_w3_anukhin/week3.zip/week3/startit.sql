-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Янв 07 2019 г., 14:30
-- Версия сервера: 10.1.33-MariaDB
-- Версия PHP: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `startit`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-12-23 19:12:20', '2018-12-23 16:12:20', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/startit', 'yes'),
(2, 'home', 'http://localhost/startit', 'yes'),
(3, 'blogname', 'startit', 'yes'),
(4, 'blogdescription', 'Ещё один сайт на WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'steell.overseer@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=40&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:41:\"advanced-custom-fields-pro-master/acf.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'startit', 'yes'),
(41, 'stylesheet', 'startit', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '40', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '79', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'WPLANG', 'ru_RU', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'cron', 'a:5:{i:1546870341;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1546870674;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1546877541;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1546877578;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(113, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1545582741;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(130, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:25:\"steell.overseer@gmail.com\";s:7:\"version\";s:5:\"4.9.9\";s:9:\"timestamp\";i:1545581574;}', 'no'),
(136, 'can_compress_scripts', '1', 'no'),
(147, 'current_theme', '', 'yes'),
(148, 'theme_mods_startit', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"menutop\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1545584536;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(149, 'theme_switched', '', 'yes'),
(158, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:3:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.0.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.0.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.2\";s:7:\"version\";s:5:\"5.0.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.2\";s:7:\"version\";s:5:\"5.0.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.2\";s:7:\"version\";s:5:\"5.0.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1546853057;s:15:\"version_checked\";s:5:\"4.9.9\";s:12:\"translations\";a:0:{}}', 'no'),
(186, 'category_children', 'a:0:{}', 'yes'),
(187, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(188, '_transient_timeout_plugin_slugs', '1546872937', 'no'),
(189, '_transient_plugin_slugs', 'a:3:{i:0;s:41:\"advanced-custom-fields-pro-master/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:9:\"hello.php\";}', 'no'),
(190, 'recently_activated', 'a:0:{}', 'yes'),
(191, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1546797288', 'no'),
(192, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4537;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3201;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2604;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2463;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1896;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1707;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1693;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1462;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1419;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1418;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1416;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1346;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1288;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1275;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1128;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1084;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1068;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1044;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:966;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:911;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:840;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:827;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:814;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:751;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:720;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:709;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:704;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:701;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:692;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:681;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:674;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:671;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:653;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:648;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:634;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:629;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:622;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:611;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:611;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:607;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:575;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:560;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:553;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:551;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:550;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:542;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:528;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:521;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:521;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:519;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:515;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:506;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:500;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:491;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:490;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:486;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:468;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:468;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:461;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:454;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:451;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:449;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:447;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:429;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:429;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:423;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:419;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:417;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:412;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:398;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:393;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:391;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:382;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:376;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:375;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:374;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:373;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:373;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:360;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:357;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:356;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:353;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:348;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:346;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:343;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:340;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:339;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:335;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:322;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:318;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:315;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:315;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:314;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:310;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:309;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:305;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:304;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:304;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:303;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:303;}}', 'no'),
(197, 'acf_version', '5.7.9', 'yes'),
(205, '_transient_timeout_acf_plugin_updates', '1546877627', 'no'),
(206, '_transient_acf_plugin_updates', 'a:4:{s:7:\"plugins\";a:0:{}s:10:\"expiration\";i:86400;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:41:\"advanced-custom-fields-pro-master/acf.php\";s:5:\"5.7.9\";}}', 'no'),
(213, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1546859026;s:7:\"checked\";a:4:{s:7:\"startit\";s:0:\"\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:3:{s:13:\"twentyfifteen\";a:4:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.2\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.2.zip\";}s:15:\"twentyseventeen\";a:4:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.1.9.zip\";}s:13:\"twentysixteen\";a:4:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.1.7.zip\";}}s:12:\"translations\";a:0:{}}', 'no'),
(214, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1546853055;s:8:\"response\";a:1:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:1:{s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(216, '_site_transient_timeout_available_translations', '1546863717', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(217, '_site_transient_available_translations', 'a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-20 10:33:58\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-17 17:05:43\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 08:43:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-05 11:37:23\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 01:37:42\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 06:21:35\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 13:53:59\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 11:11:55\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-07-06 08:46:24\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-28 17:11:33\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:47:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:48:22\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 12:30:09\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-19 08:39:44\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 03:45:55\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 08:10:56\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 03:45:44\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-10 07:51:56\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-29 20:54:51\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 12:04:58\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 13:48:04\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 13:30:18\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-10 17:20:09\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-15 16:32:57\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 05:08:30\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 14:52:01\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-04 08:05:41\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2019-01-02 11:16:38\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 06:13:38\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-08 18:24:55\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 07:59:52\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 18:30:34\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2019-01-02 09:46:59\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 10:29:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-31 15:17:58\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 17:50:34\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-02 06:28:35\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-22 02:28:45\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-15 12:45:20\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-11 00:57:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-15 07:54:23\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.9/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-15 07:35:44\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2019-01-07 07:51:16\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 22:52:57\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 07:38:39\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-17 18:27:57\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 17:19:39\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 09:30:48\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-14 13:25:59\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-26 03:44:44\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 09:37:31\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 09:40:00\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 20:59:54\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 09:58:27\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-02 17:08:41\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 21:28:43\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-13 07:00:06\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-24 10:37:55\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.9/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-11 06:46:15\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-06 02:26:39\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-21 00:30:35\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-09 00:56:52\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2019-01-06 14:43:54\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.9/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}', 'no'),
(221, '_site_transient_timeout_theme_roots', '1546860825', 'no'),
(222, '_site_transient_theme_roots', 'a:4:{s:7:\"startit\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 3, '_edit_lock', '1546448194:1'),
(4, 2, '_edit_lock', '1546790182:1'),
(5, 5, '_menu_item_type', 'custom'),
(6, 5, '_menu_item_menu_item_parent', '0'),
(7, 5, '_menu_item_object_id', '5'),
(8, 5, '_menu_item_object', 'custom'),
(9, 5, '_menu_item_target', ''),
(10, 5, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(11, 5, '_menu_item_xfn', ''),
(12, 5, '_menu_item_url', 'http://localhost/startit/'),
(13, 5, '_menu_item_orphaned', '1546784233'),
(160, 32, '_edit_last', '1'),
(161, 32, '_edit_lock', '1546786929:1'),
(162, 34, '_menu_item_type', 'custom'),
(163, 34, '_menu_item_menu_item_parent', '0'),
(164, 34, '_menu_item_object_id', '34'),
(165, 34, '_menu_item_object', 'custom'),
(166, 34, '_menu_item_target', ''),
(167, 34, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(168, 34, '_menu_item_xfn', ''),
(169, 34, '_menu_item_url', '#slider'),
(171, 35, '_menu_item_type', 'custom'),
(172, 35, '_menu_item_menu_item_parent', '0'),
(173, 35, '_menu_item_object_id', '35'),
(174, 35, '_menu_item_object', 'custom'),
(175, 35, '_menu_item_target', ''),
(176, 35, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(177, 35, '_menu_item_xfn', ''),
(178, 35, '_menu_item_url', '#services'),
(180, 36, '_menu_item_type', 'custom'),
(181, 36, '_menu_item_menu_item_parent', '0'),
(182, 36, '_menu_item_object_id', '36'),
(183, 36, '_menu_item_object', 'custom'),
(184, 36, '_menu_item_target', ''),
(185, 36, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(186, 36, '_menu_item_xfn', ''),
(187, 36, '_menu_item_url', '#about'),
(189, 37, '_menu_item_type', 'custom'),
(190, 37, '_menu_item_menu_item_parent', '0'),
(191, 37, '_menu_item_object_id', '37'),
(192, 37, '_menu_item_object', 'custom'),
(193, 37, '_menu_item_target', ''),
(194, 37, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(195, 37, '_menu_item_xfn', ''),
(196, 37, '_menu_item_url', '#works'),
(198, 38, '_menu_item_type', 'custom'),
(199, 38, '_menu_item_menu_item_parent', '0'),
(200, 38, '_menu_item_object_id', '38'),
(201, 38, '_menu_item_object', 'custom'),
(202, 38, '_menu_item_target', ''),
(203, 38, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(204, 38, '_menu_item_xfn', ''),
(205, 38, '_menu_item_url', '#blog'),
(207, 39, '_menu_item_type', 'custom'),
(208, 39, '_menu_item_menu_item_parent', '0'),
(209, 39, '_menu_item_object_id', '39'),
(210, 39, '_menu_item_object', 'custom'),
(211, 39, '_menu_item_target', ''),
(212, 39, '_menu_item_classes', 'a:1:{i:0;s:9:\"menu-item\";}'),
(213, 39, '_menu_item_xfn', ''),
(214, 39, '_menu_item_url', '#contact'),
(215, 40, '_edit_last', '1'),
(216, 40, '_edit_lock', '1546867329:1'),
(217, 40, '_wp_page_template', 'default'),
(218, 32, '_wp_trash_meta_status', 'publish'),
(219, 32, '_wp_trash_meta_time', '1546853414'),
(220, 32, '_wp_desired_post_slug', 'group_5c32172aa5d9d'),
(221, 33, '_wp_trash_meta_status', 'publish'),
(222, 33, '_wp_trash_meta_time', '1546853414'),
(223, 33, '_wp_desired_post_slug', 'field_5c32176f84997'),
(224, 42, '_edit_last', '1'),
(225, 42, '_edit_lock', '1546866734:1'),
(226, 44, '_wp_attached_file', '2019/01/logo.png'),
(227, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:78;s:6:\"height\";i:64;s:4:\"file\";s:16:\"2019/01/logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(228, 40, 'logo-img-header', '44'),
(229, 40, '_logo-img-header', 'field_5c331c4969119'),
(230, 45, 'logo-img-header', '44'),
(231, 45, '_logo-img-header', 'field_5c331c4969119'),
(232, 40, 'header-text', 'Creative Agency Template'),
(233, 40, '_header-text', 'field_5c331d847cfee'),
(234, 47, 'logo-img-header', '44'),
(235, 47, '_logo-img-header', 'field_5c331c4969119'),
(236, 47, 'header-text', 'Creative Agency Template'),
(237, 47, '_header-text', 'field_5c331d847cfee'),
(238, 48, '_edit_last', '1'),
(239, 48, '_edit_lock', '1546857892:1'),
(240, 40, 'service-list_0_list-nmbr', '01'),
(241, 40, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(242, 40, 'service-list_0_list-hdr', 'Web Designing'),
(243, 40, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(244, 40, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(245, 40, '_service-list_0_list-txt', 'field_5c332002fa328'),
(246, 40, 'service-list_1_list-nmbr', '02'),
(247, 40, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(248, 40, 'service-list_1_list-hdr', 'Photography'),
(249, 40, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(250, 40, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(251, 40, '_service-list_1_list-txt', 'field_5c332002fa328'),
(252, 40, 'service-list_2_list-nmbr', '03'),
(253, 40, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(254, 40, 'service-list_2_list-hdr', 'Art Direction'),
(255, 40, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(256, 40, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(257, 40, '_service-list_2_list-txt', 'field_5c332002fa328'),
(258, 40, 'service-list', '3'),
(259, 40, '_service-list', 'field_5c331f35fa325'),
(260, 53, 'logo-img-header', '44'),
(261, 53, '_logo-img-header', 'field_5c331c4969119'),
(262, 53, 'header-text', 'Creative Agency Template'),
(263, 53, '_header-text', 'field_5c331d847cfee'),
(264, 53, 'service-list_0_list-nmbr', '01'),
(265, 53, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(266, 53, 'service-list_0_list-hdr', 'Web Designing'),
(267, 53, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(268, 53, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(269, 53, '_service-list_0_list-txt', 'field_5c332002fa328'),
(270, 53, 'service-list_1_list-nmbr', '02'),
(271, 53, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(272, 53, 'service-list_1_list-hdr', 'Photography'),
(273, 53, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(274, 53, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(275, 53, '_service-list_1_list-txt', 'field_5c332002fa328'),
(276, 53, 'service-list_2_list-nmbr', '03'),
(277, 53, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(278, 53, 'service-list_2_list-hdr', 'Art Direction'),
(279, 53, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(280, 53, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(281, 53, '_service-list_2_list-txt', 'field_5c332002fa328'),
(282, 53, 'service-list', '3'),
(283, 53, '_service-list', 'field_5c331f35fa325'),
(284, 54, '_edit_last', '1'),
(285, 54, '_edit_lock', '1546857072:1'),
(286, 40, 'header-about', 'About Company'),
(287, 40, '_header-about', 'field_5c3323f446b21'),
(288, 40, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(289, 40, '_subheader-adout', 'field_5c33243d46b22'),
(290, 40, 'text-about', ''),
(291, 40, '_text-about', 'field_5c33246946b23'),
(292, 59, 'logo-img-header', '44'),
(293, 59, '_logo-img-header', 'field_5c331c4969119'),
(294, 59, 'header-text', 'Creative Agency Template'),
(295, 59, '_header-text', 'field_5c331d847cfee'),
(296, 59, 'service-list_0_list-nmbr', '01'),
(297, 59, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(298, 59, 'service-list_0_list-hdr', 'Web Designing'),
(299, 59, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(300, 59, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(301, 59, '_service-list_0_list-txt', 'field_5c332002fa328'),
(302, 59, 'service-list_1_list-nmbr', '02'),
(303, 59, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(304, 59, 'service-list_1_list-hdr', 'Photography'),
(305, 59, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(306, 59, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(307, 59, '_service-list_1_list-txt', 'field_5c332002fa328'),
(308, 59, 'service-list_2_list-nmbr', '03'),
(309, 59, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(310, 59, 'service-list_2_list-hdr', 'Art Direction'),
(311, 59, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(312, 59, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(313, 59, '_service-list_2_list-txt', 'field_5c332002fa328'),
(314, 59, 'service-list', '3'),
(315, 59, '_service-list', 'field_5c331f35fa325'),
(316, 59, 'header-about', 'About Company'),
(317, 59, '_header-about', 'field_5c3323f446b21'),
(318, 59, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(319, 59, '_subheader-adout', 'field_5c33243d46b22'),
(320, 59, 'text-about', ''),
(321, 59, '_text-about', 'field_5c33246946b23'),
(322, 66, '_wp_attached_file', '2019/01/img1.jpg'),
(323, 66, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:280;s:4:\"file\";s:16:\"2019/01/img1.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"img1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"img1-300x179.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:179;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:16:\"img1-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:16:\"img1-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:15:\"img1-126x75.jpg\";s:5:\"width\";i:126;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:16:\"img1-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:16:\"img1-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(324, 67, '_wp_attached_file', '2019/01/img2.jpg'),
(325, 67, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:275;s:6:\"height\";i:280;s:4:\"file\";s:16:\"2019/01/img2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"img2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:16:\"img2-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:16:\"img2-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:14:\"img2-74x75.jpg\";s:5:\"width\";i:74;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:16:\"img2-275x150.jpg\";s:5:\"width\";i:275;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:16:\"img2-275x133.jpg\";s:5:\"width\";i:275;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(326, 68, '_wp_attached_file', '2019/01/img3.jpg'),
(327, 68, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:275;s:6:\"height\";i:280;s:4:\"file\";s:16:\"2019/01/img3.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"img3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:16:\"img3-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:16:\"img3-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:14:\"img3-74x75.jpg\";s:5:\"width\";i:74;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:16:\"img3-275x150.jpg\";s:5:\"width\";i:275;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:16:\"img3-275x133.jpg\";s:5:\"width\";i:275;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(328, 40, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(329, 40, '_text-p1-about', 'field_5c3326c1f07c4'),
(330, 40, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(331, 40, '_text-p2-about', 'field_5c3326f3f07c5'),
(332, 40, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(333, 40, '_text-p3-about', 'field_5c332707f07c6'),
(334, 40, 'image-1-about', '66'),
(335, 40, '_image-1-about', 'field_5c33272e2f33a'),
(336, 40, 'image-2-about', '67'),
(337, 40, '_image-2-about', 'field_5c33281b2f33b'),
(338, 40, 'image-3-about', '68'),
(339, 40, '_image-3-about', 'field_5c3328432f33c'),
(340, 69, 'logo-img-header', '44'),
(341, 69, '_logo-img-header', 'field_5c331c4969119'),
(342, 69, 'header-text', 'Creative Agency Template'),
(343, 69, '_header-text', 'field_5c331d847cfee'),
(344, 69, 'service-list_0_list-nmbr', '01'),
(345, 69, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(346, 69, 'service-list_0_list-hdr', 'Web Designing'),
(347, 69, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(348, 69, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(349, 69, '_service-list_0_list-txt', 'field_5c332002fa328'),
(350, 69, 'service-list_1_list-nmbr', '02'),
(351, 69, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(352, 69, 'service-list_1_list-hdr', 'Photography'),
(353, 69, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(354, 69, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(355, 69, '_service-list_1_list-txt', 'field_5c332002fa328'),
(356, 69, 'service-list_2_list-nmbr', '03'),
(357, 69, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(358, 69, 'service-list_2_list-hdr', 'Art Direction'),
(359, 69, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(360, 69, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(361, 69, '_service-list_2_list-txt', 'field_5c332002fa328'),
(362, 69, 'service-list', '3'),
(363, 69, '_service-list', 'field_5c331f35fa325'),
(364, 69, 'header-about', 'About Company'),
(365, 69, '_header-about', 'field_5c3323f446b21'),
(366, 69, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(367, 69, '_subheader-adout', 'field_5c33243d46b22'),
(368, 69, 'text-about', ''),
(369, 69, '_text-about', 'field_5c33246946b23'),
(370, 69, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(371, 69, '_text-p1-about', 'field_5c3326c1f07c4'),
(372, 69, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(373, 69, '_text-p2-about', 'field_5c3326f3f07c5'),
(374, 69, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(375, 69, '_text-p3-about', 'field_5c332707f07c6'),
(376, 69, 'image-1-about', '66'),
(377, 69, '_image-1-about', 'field_5c33272e2f33a'),
(378, 69, 'image-2-about', '67'),
(379, 69, '_image-2-about', 'field_5c33281b2f33b'),
(380, 69, 'image-3-about', '68'),
(381, 69, '_image-3-about', 'field_5c3328432f33c'),
(382, 40, 'service-header', 'Our Services'),
(383, 40, '_service-header', 'field_5c332b4f09dca'),
(384, 40, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(385, 40, '_service-subheader', 'field_5c332b7709dcb'),
(386, 72, 'logo-img-header', '44'),
(387, 72, '_logo-img-header', 'field_5c331c4969119'),
(388, 72, 'header-text', 'Creative Agency Template'),
(389, 72, '_header-text', 'field_5c331d847cfee'),
(390, 72, 'service-list_0_list-nmbr', '01'),
(391, 72, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(392, 72, 'service-list_0_list-hdr', 'Web Designing'),
(393, 72, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(394, 72, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(395, 72, '_service-list_0_list-txt', 'field_5c332002fa328'),
(396, 72, 'service-list_1_list-nmbr', '02'),
(397, 72, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(398, 72, 'service-list_1_list-hdr', 'Photography'),
(399, 72, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(400, 72, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(401, 72, '_service-list_1_list-txt', 'field_5c332002fa328'),
(402, 72, 'service-list_2_list-nmbr', '03'),
(403, 72, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(404, 72, 'service-list_2_list-hdr', 'Art Direction'),
(405, 72, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(406, 72, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(407, 72, '_service-list_2_list-txt', 'field_5c332002fa328'),
(408, 72, 'service-list', '3'),
(409, 72, '_service-list', 'field_5c331f35fa325'),
(410, 72, 'header-about', 'About Company'),
(411, 72, '_header-about', 'field_5c3323f446b21'),
(412, 72, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(413, 72, '_subheader-adout', 'field_5c33243d46b22'),
(414, 72, 'text-about', ''),
(415, 72, '_text-about', 'field_5c33246946b23'),
(416, 72, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(417, 72, '_text-p1-about', 'field_5c3326c1f07c4'),
(418, 72, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(419, 72, '_text-p2-about', 'field_5c3326f3f07c5'),
(420, 72, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(421, 72, '_text-p3-about', 'field_5c332707f07c6'),
(422, 72, 'image-1-about', '66'),
(423, 72, '_image-1-about', 'field_5c33272e2f33a'),
(424, 72, 'image-2-about', '67'),
(425, 72, '_image-2-about', 'field_5c33281b2f33b'),
(426, 72, 'image-3-about', '68'),
(427, 72, '_image-3-about', 'field_5c3328432f33c'),
(428, 72, 'service-header', 'Our Services'),
(429, 72, '_service-header', 'field_5c332b4f09dca'),
(430, 72, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(431, 72, '_service-subheader', 'field_5c332b7709dcb'),
(432, 74, '_wp_attached_file', '2019/01/slider-bg1.jpg'),
(433, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1900;s:6:\"height\";i:900;s:4:\"file\";s:22:\"2019/01/slider-bg1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"slider-bg1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"slider-bg1-300x142.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:142;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"slider-bg1-768x364.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:364;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"slider-bg1-1024x485.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:485;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:22:\"slider-bg1-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:22:\"slider-bg1-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:21:\"slider-bg1-158x75.jpg\";s:5:\"width\";i:158;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:22:\"slider-bg1-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:22:\"slider-bg1-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(434, 40, 'header-background-img', '74'),
(435, 40, '_header-background-img', 'field_5c332e3eca9fd'),
(436, 75, 'logo-img-header', '44'),
(437, 75, '_logo-img-header', 'field_5c331c4969119'),
(438, 75, 'header-text', 'Creative Agency Template'),
(439, 75, '_header-text', 'field_5c331d847cfee'),
(440, 75, 'service-list_0_list-nmbr', '01'),
(441, 75, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(442, 75, 'service-list_0_list-hdr', 'Web Designing'),
(443, 75, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(444, 75, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(445, 75, '_service-list_0_list-txt', 'field_5c332002fa328'),
(446, 75, 'service-list_1_list-nmbr', '02'),
(447, 75, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(448, 75, 'service-list_1_list-hdr', 'Photography'),
(449, 75, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(450, 75, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(451, 75, '_service-list_1_list-txt', 'field_5c332002fa328'),
(452, 75, 'service-list_2_list-nmbr', '03'),
(453, 75, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(454, 75, 'service-list_2_list-hdr', 'Art Direction'),
(455, 75, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(456, 75, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(457, 75, '_service-list_2_list-txt', 'field_5c332002fa328'),
(458, 75, 'service-list', '3'),
(459, 75, '_service-list', 'field_5c331f35fa325'),
(460, 75, 'header-about', 'About Company'),
(461, 75, '_header-about', 'field_5c3323f446b21'),
(462, 75, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(463, 75, '_subheader-adout', 'field_5c33243d46b22'),
(464, 75, 'text-about', ''),
(465, 75, '_text-about', 'field_5c33246946b23'),
(466, 75, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(467, 75, '_text-p1-about', 'field_5c3326c1f07c4'),
(468, 75, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(469, 75, '_text-p2-about', 'field_5c3326f3f07c5'),
(470, 75, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(471, 75, '_text-p3-about', 'field_5c332707f07c6'),
(472, 75, 'image-1-about', '66'),
(473, 75, '_image-1-about', 'field_5c33272e2f33a'),
(474, 75, 'image-2-about', '67'),
(475, 75, '_image-2-about', 'field_5c33281b2f33b'),
(476, 75, 'image-3-about', '68'),
(477, 75, '_image-3-about', 'field_5c3328432f33c'),
(478, 75, 'service-header', 'Our Services'),
(479, 75, '_service-header', 'field_5c332b4f09dca'),
(480, 75, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(481, 75, '_service-subheader', 'field_5c332b7709dcb'),
(482, 75, 'header-background-img', '74'),
(483, 75, '_header-background-img', 'field_5c332e3eca9fd'),
(484, 76, '_edit_last', '1'),
(485, 76, '_edit_lock', '1546863537:1'),
(486, 79, '_wp_attached_file', '2019/01/favicon.jpg'),
(487, 79, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:16;s:6:\"height\";i:16;s:4:\"file\";s:19:\"2019/01/favicon.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(488, 80, '_wp_trash_meta_status', 'publish'),
(489, 80, '_wp_trash_meta_time', '1546859093'),
(490, 40, 'header-works', 'Our Portfolio'),
(491, 40, '_header-works', 'field_5c3330b52fe1e'),
(492, 40, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(493, 40, '_subheader-works', 'field_5c3330d12fe1f'),
(494, 81, 'logo-img-header', '44'),
(495, 81, '_logo-img-header', 'field_5c331c4969119'),
(496, 81, 'header-text', 'Creative Agency Template'),
(497, 81, '_header-text', 'field_5c331d847cfee'),
(498, 81, 'service-list_0_list-nmbr', '01'),
(499, 81, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(500, 81, 'service-list_0_list-hdr', 'Web Designing'),
(501, 81, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(502, 81, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(503, 81, '_service-list_0_list-txt', 'field_5c332002fa328'),
(504, 81, 'service-list_1_list-nmbr', '02'),
(505, 81, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(506, 81, 'service-list_1_list-hdr', 'Photography'),
(507, 81, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(508, 81, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(509, 81, '_service-list_1_list-txt', 'field_5c332002fa328'),
(510, 81, 'service-list_2_list-nmbr', '03'),
(511, 81, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(512, 81, 'service-list_2_list-hdr', 'Art Direction'),
(513, 81, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(514, 81, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(515, 81, '_service-list_2_list-txt', 'field_5c332002fa328'),
(516, 81, 'service-list', '3'),
(517, 81, '_service-list', 'field_5c331f35fa325'),
(518, 81, 'header-about', 'About Company'),
(519, 81, '_header-about', 'field_5c3323f446b21'),
(520, 81, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(521, 81, '_subheader-adout', 'field_5c33243d46b22'),
(522, 81, 'text-about', ''),
(523, 81, '_text-about', 'field_5c33246946b23'),
(524, 81, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(525, 81, '_text-p1-about', 'field_5c3326c1f07c4'),
(526, 81, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(527, 81, '_text-p2-about', 'field_5c3326f3f07c5'),
(528, 81, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(529, 81, '_text-p3-about', 'field_5c332707f07c6'),
(530, 81, 'image-1-about', '66'),
(531, 81, '_image-1-about', 'field_5c33272e2f33a'),
(532, 81, 'image-2-about', '67'),
(533, 81, '_image-2-about', 'field_5c33281b2f33b'),
(534, 81, 'image-3-about', '68'),
(535, 81, '_image-3-about', 'field_5c3328432f33c'),
(536, 81, 'service-header', 'Our Services'),
(537, 81, '_service-header', 'field_5c332b4f09dca'),
(538, 81, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(539, 81, '_service-subheader', 'field_5c332b7709dcb'),
(540, 81, 'header-background-img', '74'),
(541, 81, '_header-background-img', 'field_5c332e3eca9fd'),
(542, 81, 'header-works', 'Our Portfolio'),
(543, 81, '_header-works', 'field_5c3330b52fe1e'),
(544, 81, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(545, 81, '_subheader-works', 'field_5c3330d12fe1f'),
(546, 103, '_wp_attached_file', '2019/01/project-1.jpg'),
(547, 103, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-1.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-1-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-1-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-1-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-1-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-1-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(548, 104, '_wp_attached_file', '2019/01/project-2.jpg'),
(549, 104, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-2.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-2-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-2-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-2-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-2-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-2-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(550, 105, '_wp_attached_file', '2019/01/project-3.jpg'),
(551, 105, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-3.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-3-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-3-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-3-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-3-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-3-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(552, 106, '_wp_attached_file', '2019/01/project-4.jpg'),
(553, 106, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-4.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-4-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-4-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-4-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-4-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-4-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(554, 107, '_wp_attached_file', '2019/01/project-5.jpg'),
(555, 107, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-5.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-5-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-5-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-5-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-5-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-5-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(556, 108, '_wp_attached_file', '2019/01/project-6.jpg'),
(557, 108, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-6.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-6-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-6-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-6-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-6-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-6-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-6-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(558, 109, '_wp_attached_file', '2019/01/project-7.jpg'),
(559, 109, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:650;s:4:\"file\";s:21:\"2019/01/project-7.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-7-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-7-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-7-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-7-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-7-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-7-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(560, 110, '_wp_attached_file', '2019/01/project-8.jpg'),
(561, 110, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:21:\"2019/01/project-8.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"project-8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"project-8-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:21:\"project-8-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:21:\"project-8-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:19:\"project-8-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:21:\"project-8-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:21:\"project-8-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(562, 40, 'filter-1-works', 'All'),
(563, 40, '_filter-1-works', 'field_5c3334235a30e'),
(564, 40, 'filter-2-works', 'Web Design'),
(565, 40, '_filter-2-works', 'field_5c333cb15a30f'),
(566, 40, 'filter-3-works', 'Art Direction'),
(567, 40, '_filter-3-works', 'field_5c333cbd5a310'),
(568, 40, 'filter-4-works', 'Creative'),
(569, 40, '_filter-4-works', 'field_5c333cc35a311'),
(570, 40, 'filter-5-works', 'WordPress'),
(571, 40, '_filter-5-works', 'field_5c333cc95a312'),
(572, 40, 'image-1-works', '103'),
(573, 40, '_image-1-works', 'field_5c333d0c62cbd'),
(574, 40, 'image-name-1-works', 'New Packaging'),
(575, 40, '_image-name-1-works', 'field_5c333d3b62cbe'),
(576, 40, 'image-2-works', '104'),
(577, 40, '_image-2-works', 'field_5c333d4762cbf'),
(578, 40, 'image-name-2-works', 'Healty Drinks'),
(579, 40, '_image-name-2-works', 'field_5c333d5362cc0'),
(580, 40, 'image-3-works', '105'),
(581, 40, '_image-3-works', 'field_5c333d6a62cc1'),
(582, 40, 'image-name-3-works', 'Smart Bottle'),
(583, 40, '_image-name-3-works', 'field_5c333d8262cc2'),
(584, 40, 'image-4-works', '106'),
(585, 40, '_image-4-works', 'field_5c333d8f62cc3'),
(586, 40, 'image-name-4-works', 'Stored Album'),
(587, 40, '_image-name-4-works', 'field_5c333da162cc4'),
(588, 40, 'image-5-works', '107'),
(589, 40, '_image-5-works', 'field_5c333e966741a'),
(590, 40, 'image-name-5-works', 'Shopping Bag'),
(591, 40, '_image-name-5-works', 'field_5c333fd2af262'),
(592, 40, 'image-6-works', '108'),
(593, 40, '_image-6-works', 'field_5c33401d1c694'),
(594, 40, 'image-name-6-works', 'Coffee Break'),
(595, 40, '_image-name-6-works', 'field_5c3340401c695'),
(596, 40, 'image-7-works', '109'),
(597, 40, '_image-7-works', 'field_5c3340654ff12'),
(598, 40, 'image-name-7-works', 'Clean Water'),
(599, 40, '_image-name-7-works', 'field_5c3340844ff13'),
(600, 40, 'image-8-works', '110'),
(601, 40, '_image-8-works', 'field_5c3340bb7064b'),
(602, 40, 'image-name-8-works', 'Total Refreshment'),
(603, 40, '_image-name-8-works', 'field_5c3340dc7064c'),
(604, 111, 'logo-img-header', '44'),
(605, 111, '_logo-img-header', 'field_5c331c4969119'),
(606, 111, 'header-text', 'Creative Agency Template'),
(607, 111, '_header-text', 'field_5c331d847cfee'),
(608, 111, 'service-list_0_list-nmbr', '01'),
(609, 111, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(610, 111, 'service-list_0_list-hdr', 'Web Designing'),
(611, 111, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(612, 111, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(613, 111, '_service-list_0_list-txt', 'field_5c332002fa328'),
(614, 111, 'service-list_1_list-nmbr', '02'),
(615, 111, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(616, 111, 'service-list_1_list-hdr', 'Photography'),
(617, 111, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(618, 111, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(619, 111, '_service-list_1_list-txt', 'field_5c332002fa328'),
(620, 111, 'service-list_2_list-nmbr', '03'),
(621, 111, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(622, 111, 'service-list_2_list-hdr', 'Art Direction'),
(623, 111, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(624, 111, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(625, 111, '_service-list_2_list-txt', 'field_5c332002fa328'),
(626, 111, 'service-list', '3'),
(627, 111, '_service-list', 'field_5c331f35fa325'),
(628, 111, 'header-about', 'About Company'),
(629, 111, '_header-about', 'field_5c3323f446b21'),
(630, 111, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(631, 111, '_subheader-adout', 'field_5c33243d46b22'),
(632, 111, 'text-about', ''),
(633, 111, '_text-about', 'field_5c33246946b23'),
(634, 111, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(635, 111, '_text-p1-about', 'field_5c3326c1f07c4'),
(636, 111, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(637, 111, '_text-p2-about', 'field_5c3326f3f07c5'),
(638, 111, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(639, 111, '_text-p3-about', 'field_5c332707f07c6'),
(640, 111, 'image-1-about', '66'),
(641, 111, '_image-1-about', 'field_5c33272e2f33a'),
(642, 111, 'image-2-about', '67'),
(643, 111, '_image-2-about', 'field_5c33281b2f33b'),
(644, 111, 'image-3-about', '68'),
(645, 111, '_image-3-about', 'field_5c3328432f33c'),
(646, 111, 'service-header', 'Our Services'),
(647, 111, '_service-header', 'field_5c332b4f09dca'),
(648, 111, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(649, 111, '_service-subheader', 'field_5c332b7709dcb'),
(650, 111, 'header-background-img', '74'),
(651, 111, '_header-background-img', 'field_5c332e3eca9fd'),
(652, 111, 'header-works', 'Our Portfolio'),
(653, 111, '_header-works', 'field_5c3330b52fe1e'),
(654, 111, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(655, 111, '_subheader-works', 'field_5c3330d12fe1f'),
(656, 111, 'filter-1-works', 'All'),
(657, 111, '_filter-1-works', 'field_5c3334235a30e'),
(658, 111, 'filter-2-works', 'Web Design'),
(659, 111, '_filter-2-works', 'field_5c333cb15a30f'),
(660, 111, 'filter-3-works', 'Art Direction'),
(661, 111, '_filter-3-works', 'field_5c333cbd5a310'),
(662, 111, 'filter-4-works', 'Creative'),
(663, 111, '_filter-4-works', 'field_5c333cc35a311'),
(664, 111, 'filter-5-works', 'WordPress'),
(665, 111, '_filter-5-works', 'field_5c333cc95a312'),
(666, 111, 'image-1-works', '103'),
(667, 111, '_image-1-works', 'field_5c333d0c62cbd'),
(668, 111, 'image-name-1-works', 'New Packaging'),
(669, 111, '_image-name-1-works', 'field_5c333d3b62cbe'),
(670, 111, 'image-2-works', '104'),
(671, 111, '_image-2-works', 'field_5c333d4762cbf');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(672, 111, 'image-name-2-works', 'Healty Drinks'),
(673, 111, '_image-name-2-works', 'field_5c333d5362cc0'),
(674, 111, 'image-3-works', '105'),
(675, 111, '_image-3-works', 'field_5c333d6a62cc1'),
(676, 111, 'image-name-3-works', 'Smart Bottle'),
(677, 111, '_image-name-3-works', 'field_5c333d8262cc2'),
(678, 111, 'image-4-works', '106'),
(679, 111, '_image-4-works', 'field_5c333d8f62cc3'),
(680, 111, 'image-name-4-works', 'Stored Album'),
(681, 111, '_image-name-4-works', 'field_5c333da162cc4'),
(682, 111, 'image-5-works', '107'),
(683, 111, '_image-5-works', 'field_5c333e966741a'),
(684, 111, 'image-name-5-works', 'Shopping Bag'),
(685, 111, '_image-name-5-works', 'field_5c333fd2af262'),
(686, 111, 'image-6-works', '108'),
(687, 111, '_image-6-works', 'field_5c33401d1c694'),
(688, 111, 'image-name-6-works', 'Coffee Break'),
(689, 111, '_image-name-6-works', 'field_5c3340401c695'),
(690, 111, 'image-7-works', '109'),
(691, 111, '_image-7-works', 'field_5c3340654ff12'),
(692, 111, 'image-name-7-works', 'Clean Water'),
(693, 111, '_image-name-7-works', 'field_5c3340844ff13'),
(694, 111, 'image-8-works', '110'),
(695, 111, '_image-8-works', 'field_5c3340bb7064b'),
(696, 111, 'image-name-8-works', 'Total Refreshment'),
(697, 111, '_image-name-8-works', 'field_5c3340dc7064c'),
(698, 112, '_edit_last', '1'),
(699, 112, '_edit_lock', '1546866409:1'),
(700, 119, '_wp_attached_file', '2019/01/blog-1.jpg'),
(701, 119, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:370;s:6:\"height\";i:280;s:4:\"file\";s:18:\"2019/01/blog-1.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"blog-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"blog-1-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:18:\"blog-1-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:18:\"blog-1-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:16:\"blog-1-99x75.jpg\";s:5:\"width\";i:99;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:18:\"blog-1-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:18:\"blog-1-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(702, 120, '_wp_attached_file', '2019/01/blog-2.jpg'),
(703, 120, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:370;s:6:\"height\";i:280;s:4:\"file\";s:18:\"2019/01/blog-2.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"blog-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"blog-2-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:18:\"blog-2-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:18:\"blog-2-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:16:\"blog-2-99x75.jpg\";s:5:\"width\";i:99;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:18:\"blog-2-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:18:\"blog-2-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(704, 121, '_wp_attached_file', '2019/01/blog-3.jpg'),
(705, 121, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:370;s:6:\"height\";i:280;s:4:\"file\";s:18:\"2019/01/blog-3.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"blog-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"blog-3-300x227.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:227;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:18:\"blog-3-160x160.jpg\";s:5:\"width\";i:160;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:18:\"blog-3-180x180.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:16:\"blog-3-99x75.jpg\";s:5:\"width\";i:99;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:18:\"blog-3-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:18:\"blog-3-279x133.jpg\";s:5:\"width\";i:279;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(706, 40, 'blog-title', 'Latest Articles'),
(707, 40, '_blog-title', 'field_5c3344534e7b3'),
(708, 40, 'blog-subtitle', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(709, 40, '_blog-subtitle', 'field_5c3344714e7b4'),
(710, 40, 'blog-list_0_blog-list-img', '119'),
(711, 40, '_blog-list_0_blog-list-img', 'field_5c3344db9eed4'),
(712, 40, 'blog-list_0_blog-list-header', 'Create any idea to make different'),
(713, 40, '_blog-list_0_blog-list-header', 'field_5c33450e9eed5'),
(714, 40, 'blog-list_0_blog-list-url', 'Go to article'),
(715, 40, '_blog-list_0_blog-list-url', 'field_5c3345429eed6'),
(716, 40, 'blog-list_1_blog-list-img', '120'),
(717, 40, '_blog-list_1_blog-list-img', 'field_5c3344db9eed4'),
(718, 40, 'blog-list_1_blog-list-header', 'Design unique as your passion'),
(719, 40, '_blog-list_1_blog-list-header', 'field_5c33450e9eed5'),
(720, 40, 'blog-list_1_blog-list-url', 'Go to article'),
(721, 40, '_blog-list_1_blog-list-url', 'field_5c3345429eed6'),
(722, 40, 'blog-list_2_blog-list-img', '121'),
(723, 40, '_blog-list_2_blog-list-img', 'field_5c3344db9eed4'),
(724, 40, 'blog-list_2_blog-list-header', 'Do hard work to be fast & successful'),
(725, 40, '_blog-list_2_blog-list-header', 'field_5c33450e9eed5'),
(726, 40, 'blog-list_2_blog-list-url', 'Go to article'),
(727, 40, '_blog-list_2_blog-list-url', 'field_5c3345429eed6'),
(728, 40, 'blog-list', '3'),
(729, 40, '_blog-list', 'field_5c3344a59eed3'),
(730, 122, 'logo-img-header', '44'),
(731, 122, '_logo-img-header', 'field_5c331c4969119'),
(732, 122, 'header-text', 'Creative Agency Template'),
(733, 122, '_header-text', 'field_5c331d847cfee'),
(734, 122, 'service-list_0_list-nmbr', '01'),
(735, 122, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(736, 122, 'service-list_0_list-hdr', 'Web Designing'),
(737, 122, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(738, 122, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(739, 122, '_service-list_0_list-txt', 'field_5c332002fa328'),
(740, 122, 'service-list_1_list-nmbr', '02'),
(741, 122, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(742, 122, 'service-list_1_list-hdr', 'Photography'),
(743, 122, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(744, 122, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(745, 122, '_service-list_1_list-txt', 'field_5c332002fa328'),
(746, 122, 'service-list_2_list-nmbr', '03'),
(747, 122, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(748, 122, 'service-list_2_list-hdr', 'Art Direction'),
(749, 122, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(750, 122, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(751, 122, '_service-list_2_list-txt', 'field_5c332002fa328'),
(752, 122, 'service-list', '3'),
(753, 122, '_service-list', 'field_5c331f35fa325'),
(754, 122, 'header-about', 'About Company'),
(755, 122, '_header-about', 'field_5c3323f446b21'),
(756, 122, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(757, 122, '_subheader-adout', 'field_5c33243d46b22'),
(758, 122, 'text-about', ''),
(759, 122, '_text-about', 'field_5c33246946b23'),
(760, 122, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(761, 122, '_text-p1-about', 'field_5c3326c1f07c4'),
(762, 122, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(763, 122, '_text-p2-about', 'field_5c3326f3f07c5'),
(764, 122, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(765, 122, '_text-p3-about', 'field_5c332707f07c6'),
(766, 122, 'image-1-about', '66'),
(767, 122, '_image-1-about', 'field_5c33272e2f33a'),
(768, 122, 'image-2-about', '67'),
(769, 122, '_image-2-about', 'field_5c33281b2f33b'),
(770, 122, 'image-3-about', '68'),
(771, 122, '_image-3-about', 'field_5c3328432f33c'),
(772, 122, 'service-header', 'Our Services'),
(773, 122, '_service-header', 'field_5c332b4f09dca'),
(774, 122, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(775, 122, '_service-subheader', 'field_5c332b7709dcb'),
(776, 122, 'header-background-img', '74'),
(777, 122, '_header-background-img', 'field_5c332e3eca9fd'),
(778, 122, 'header-works', 'Our Portfolio'),
(779, 122, '_header-works', 'field_5c3330b52fe1e'),
(780, 122, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(781, 122, '_subheader-works', 'field_5c3330d12fe1f'),
(782, 122, 'filter-1-works', 'All'),
(783, 122, '_filter-1-works', 'field_5c3334235a30e'),
(784, 122, 'filter-2-works', 'Web Design'),
(785, 122, '_filter-2-works', 'field_5c333cb15a30f'),
(786, 122, 'filter-3-works', 'Art Direction'),
(787, 122, '_filter-3-works', 'field_5c333cbd5a310'),
(788, 122, 'filter-4-works', 'Creative'),
(789, 122, '_filter-4-works', 'field_5c333cc35a311'),
(790, 122, 'filter-5-works', 'WordPress'),
(791, 122, '_filter-5-works', 'field_5c333cc95a312'),
(792, 122, 'image-1-works', '103'),
(793, 122, '_image-1-works', 'field_5c333d0c62cbd'),
(794, 122, 'image-name-1-works', 'New Packaging'),
(795, 122, '_image-name-1-works', 'field_5c333d3b62cbe'),
(796, 122, 'image-2-works', '104'),
(797, 122, '_image-2-works', 'field_5c333d4762cbf'),
(798, 122, 'image-name-2-works', 'Healty Drinks'),
(799, 122, '_image-name-2-works', 'field_5c333d5362cc0'),
(800, 122, 'image-3-works', '105'),
(801, 122, '_image-3-works', 'field_5c333d6a62cc1'),
(802, 122, 'image-name-3-works', 'Smart Bottle'),
(803, 122, '_image-name-3-works', 'field_5c333d8262cc2'),
(804, 122, 'image-4-works', '106'),
(805, 122, '_image-4-works', 'field_5c333d8f62cc3'),
(806, 122, 'image-name-4-works', 'Stored Album'),
(807, 122, '_image-name-4-works', 'field_5c333da162cc4'),
(808, 122, 'image-5-works', '107'),
(809, 122, '_image-5-works', 'field_5c333e966741a'),
(810, 122, 'image-name-5-works', 'Shopping Bag'),
(811, 122, '_image-name-5-works', 'field_5c333fd2af262'),
(812, 122, 'image-6-works', '108'),
(813, 122, '_image-6-works', 'field_5c33401d1c694'),
(814, 122, 'image-name-6-works', 'Coffee Break'),
(815, 122, '_image-name-6-works', 'field_5c3340401c695'),
(816, 122, 'image-7-works', '109'),
(817, 122, '_image-7-works', 'field_5c3340654ff12'),
(818, 122, 'image-name-7-works', 'Clean Water'),
(819, 122, '_image-name-7-works', 'field_5c3340844ff13'),
(820, 122, 'image-8-works', '110'),
(821, 122, '_image-8-works', 'field_5c3340bb7064b'),
(822, 122, 'image-name-8-works', 'Total Refreshment'),
(823, 122, '_image-name-8-works', 'field_5c3340dc7064c'),
(824, 122, 'blog-title', 'Latest Articles'),
(825, 122, '_blog-title', 'field_5c3344534e7b3'),
(826, 122, 'blog-subtitle', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(827, 122, '_blog-subtitle', 'field_5c3344714e7b4'),
(828, 122, 'blog-list_0_blog-list-img', '119'),
(829, 122, '_blog-list_0_blog-list-img', 'field_5c3344db9eed4'),
(830, 122, 'blog-list_0_blog-list-header', 'Create any idea to make different'),
(831, 122, '_blog-list_0_blog-list-header', 'field_5c33450e9eed5'),
(832, 122, 'blog-list_0_blog-list-url', 'Go to article'),
(833, 122, '_blog-list_0_blog-list-url', 'field_5c3345429eed6'),
(834, 122, 'blog-list_1_blog-list-img', '120'),
(835, 122, '_blog-list_1_blog-list-img', 'field_5c3344db9eed4'),
(836, 122, 'blog-list_1_blog-list-header', 'Design unique as your passion'),
(837, 122, '_blog-list_1_blog-list-header', 'field_5c33450e9eed5'),
(838, 122, 'blog-list_1_blog-list-url', 'Go to article'),
(839, 122, '_blog-list_1_blog-list-url', 'field_5c3345429eed6'),
(840, 122, 'blog-list_2_blog-list-img', '121'),
(841, 122, '_blog-list_2_blog-list-img', 'field_5c3344db9eed4'),
(842, 122, 'blog-list_2_blog-list-header', 'Do hard work to be fast & successful'),
(843, 122, '_blog-list_2_blog-list-header', 'field_5c33450e9eed5'),
(844, 122, 'blog-list_2_blog-list-url', 'Go to article'),
(845, 122, '_blog-list_2_blog-list-url', 'field_5c3345429eed6'),
(846, 122, 'blog-list', '3'),
(847, 122, '_blog-list', 'field_5c3344a59eed3'),
(848, 124, '_wp_attached_file', '2019/01/shape1.png'),
(849, 124, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1980;s:6:\"height\";i:100;s:4:\"file\";s:18:\"2019/01/shape1.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"shape1-150x100.png\";s:5:\"width\";i:150;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"shape1-300x15.png\";s:5:\"width\";i:300;s:6:\"height\";i:15;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"shape1-768x39.png\";s:5:\"width\";i:768;s:6:\"height\";i:39;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"shape1-1024x52.png\";s:5:\"width\";i:1024;s:6:\"height\";i:52;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"small-thumb\";a:4:{s:4:\"file\";s:18:\"shape1-160x100.png\";s:5:\"width\";i:160;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"slider-thumb\";a:4:{s:4:\"file\";s:18:\"shape1-180x100.png\";s:5:\"width\";i:180;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"single-post-thumb\";a:4:{s:4:\"file\";s:17:\"shape1-275x14.png\";s:5:\"width\";i:275;s:6:\"height\";i:14;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"archive-thumb\";a:4:{s:4:\"file\";s:18:\"shape1-300x100.png\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"special-thumb\";a:4:{s:4:\"file\";s:18:\"shape1-279x100.png\";s:5:\"width\";i:279;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(850, 40, 'butt-down-img', '124'),
(851, 40, '_butt-down-img', 'field_5c334ff94736f'),
(852, 125, 'logo-img-header', '44'),
(853, 125, '_logo-img-header', 'field_5c331c4969119'),
(854, 125, 'header-text', 'Creative Agency Template'),
(855, 125, '_header-text', 'field_5c331d847cfee'),
(856, 125, 'service-list_0_list-nmbr', '01'),
(857, 125, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(858, 125, 'service-list_0_list-hdr', 'Web Designing'),
(859, 125, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(860, 125, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(861, 125, '_service-list_0_list-txt', 'field_5c332002fa328'),
(862, 125, 'service-list_1_list-nmbr', '02'),
(863, 125, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(864, 125, 'service-list_1_list-hdr', 'Photography'),
(865, 125, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(866, 125, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(867, 125, '_service-list_1_list-txt', 'field_5c332002fa328'),
(868, 125, 'service-list_2_list-nmbr', '03'),
(869, 125, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(870, 125, 'service-list_2_list-hdr', 'Art Direction'),
(871, 125, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(872, 125, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(873, 125, '_service-list_2_list-txt', 'field_5c332002fa328'),
(874, 125, 'service-list', '3'),
(875, 125, '_service-list', 'field_5c331f35fa325'),
(876, 125, 'header-about', 'About Company'),
(877, 125, '_header-about', 'field_5c3323f446b21'),
(878, 125, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(879, 125, '_subheader-adout', 'field_5c33243d46b22'),
(880, 125, 'text-about', ''),
(881, 125, '_text-about', 'field_5c33246946b23'),
(882, 125, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(883, 125, '_text-p1-about', 'field_5c3326c1f07c4'),
(884, 125, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(885, 125, '_text-p2-about', 'field_5c3326f3f07c5'),
(886, 125, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(887, 125, '_text-p3-about', 'field_5c332707f07c6'),
(888, 125, 'image-1-about', '66'),
(889, 125, '_image-1-about', 'field_5c33272e2f33a'),
(890, 125, 'image-2-about', '67'),
(891, 125, '_image-2-about', 'field_5c33281b2f33b'),
(892, 125, 'image-3-about', '68'),
(893, 125, '_image-3-about', 'field_5c3328432f33c'),
(894, 125, 'service-header', 'Our Services'),
(895, 125, '_service-header', 'field_5c332b4f09dca'),
(896, 125, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(897, 125, '_service-subheader', 'field_5c332b7709dcb'),
(898, 125, 'header-background-img', '74'),
(899, 125, '_header-background-img', 'field_5c332e3eca9fd'),
(900, 125, 'header-works', 'Our Portfolio'),
(901, 125, '_header-works', 'field_5c3330b52fe1e'),
(902, 125, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(903, 125, '_subheader-works', 'field_5c3330d12fe1f'),
(904, 125, 'filter-1-works', 'All'),
(905, 125, '_filter-1-works', 'field_5c3334235a30e'),
(906, 125, 'filter-2-works', 'Web Design'),
(907, 125, '_filter-2-works', 'field_5c333cb15a30f'),
(908, 125, 'filter-3-works', 'Art Direction'),
(909, 125, '_filter-3-works', 'field_5c333cbd5a310'),
(910, 125, 'filter-4-works', 'Creative'),
(911, 125, '_filter-4-works', 'field_5c333cc35a311'),
(912, 125, 'filter-5-works', 'WordPress'),
(913, 125, '_filter-5-works', 'field_5c333cc95a312'),
(914, 125, 'image-1-works', '103'),
(915, 125, '_image-1-works', 'field_5c333d0c62cbd'),
(916, 125, 'image-name-1-works', 'New Packaging'),
(917, 125, '_image-name-1-works', 'field_5c333d3b62cbe'),
(918, 125, 'image-2-works', '104'),
(919, 125, '_image-2-works', 'field_5c333d4762cbf'),
(920, 125, 'image-name-2-works', 'Healty Drinks'),
(921, 125, '_image-name-2-works', 'field_5c333d5362cc0'),
(922, 125, 'image-3-works', '105'),
(923, 125, '_image-3-works', 'field_5c333d6a62cc1'),
(924, 125, 'image-name-3-works', 'Smart Bottle'),
(925, 125, '_image-name-3-works', 'field_5c333d8262cc2'),
(926, 125, 'image-4-works', '106'),
(927, 125, '_image-4-works', 'field_5c333d8f62cc3'),
(928, 125, 'image-name-4-works', 'Stored Album'),
(929, 125, '_image-name-4-works', 'field_5c333da162cc4'),
(930, 125, 'image-5-works', '107'),
(931, 125, '_image-5-works', 'field_5c333e966741a'),
(932, 125, 'image-name-5-works', 'Shopping Bag'),
(933, 125, '_image-name-5-works', 'field_5c333fd2af262'),
(934, 125, 'image-6-works', '108'),
(935, 125, '_image-6-works', 'field_5c33401d1c694'),
(936, 125, 'image-name-6-works', 'Coffee Break'),
(937, 125, '_image-name-6-works', 'field_5c3340401c695'),
(938, 125, 'image-7-works', '109'),
(939, 125, '_image-7-works', 'field_5c3340654ff12'),
(940, 125, 'image-name-7-works', 'Clean Water'),
(941, 125, '_image-name-7-works', 'field_5c3340844ff13'),
(942, 125, 'image-8-works', '110'),
(943, 125, '_image-8-works', 'field_5c3340bb7064b'),
(944, 125, 'image-name-8-works', 'Total Refreshment'),
(945, 125, '_image-name-8-works', 'field_5c3340dc7064c'),
(946, 125, 'blog-title', 'Latest Articles'),
(947, 125, '_blog-title', 'field_5c3344534e7b3'),
(948, 125, 'blog-subtitle', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(949, 125, '_blog-subtitle', 'field_5c3344714e7b4'),
(950, 125, 'blog-list_0_blog-list-img', '119'),
(951, 125, '_blog-list_0_blog-list-img', 'field_5c3344db9eed4'),
(952, 125, 'blog-list_0_blog-list-header', 'Create any idea to make different'),
(953, 125, '_blog-list_0_blog-list-header', 'field_5c33450e9eed5'),
(954, 125, 'blog-list_0_blog-list-url', 'Go to article'),
(955, 125, '_blog-list_0_blog-list-url', 'field_5c3345429eed6'),
(956, 125, 'blog-list_1_blog-list-img', '120'),
(957, 125, '_blog-list_1_blog-list-img', 'field_5c3344db9eed4'),
(958, 125, 'blog-list_1_blog-list-header', 'Design unique as your passion'),
(959, 125, '_blog-list_1_blog-list-header', 'field_5c33450e9eed5'),
(960, 125, 'blog-list_1_blog-list-url', 'Go to article'),
(961, 125, '_blog-list_1_blog-list-url', 'field_5c3345429eed6'),
(962, 125, 'blog-list_2_blog-list-img', '121'),
(963, 125, '_blog-list_2_blog-list-img', 'field_5c3344db9eed4'),
(964, 125, 'blog-list_2_blog-list-header', 'Do hard work to be fast & successful'),
(965, 125, '_blog-list_2_blog-list-header', 'field_5c33450e9eed5'),
(966, 125, 'blog-list_2_blog-list-url', 'Go to article'),
(967, 125, '_blog-list_2_blog-list-url', 'field_5c3345429eed6'),
(968, 125, 'blog-list', '3'),
(969, 125, '_blog-list', 'field_5c3344a59eed3'),
(970, 125, 'butt-down-img', '124'),
(971, 125, '_butt-down-img', 'field_5c334ff94736f'),
(972, 126, '_edit_last', '1'),
(973, 126, '_edit_lock', '1546867537:1'),
(974, 40, 'phone-footer', 'Phone'),
(975, 40, '_phone-footer', 'field_5c33517733b27'),
(976, 40, 'phone-nbr-footer', '+ 123 - 456 -789, + 987 - 654 - 321'),
(977, 40, '_phone-nbr-footer', 'field_5c3351ab33b28'),
(978, 40, 'address-footer', 'Address'),
(979, 40, '_address-footer', 'field_5c3351cb33b29'),
(980, 40, 'address-txt-footer', 'RK road, United states of America'),
(981, 40, '_address-txt-footer', 'field_5c33520133b2a'),
(982, 40, 'e-mail-footer', 'E-mail'),
(983, 40, '_e-mail-footer', 'field_5c33522933b2b'),
(984, 40, 'e-mail-name-footer', 'carrbyagency@gmail.com'),
(985, 40, '_e-mail-name-footer', 'field_5c33525133b2c'),
(986, 40, 'copyright-footer', '&copy; 2018 - carrby.agency. Created by <a href=\"#\">WP ThemeBooster</a> All rights reserved.'),
(987, 40, '_copyright-footer', 'field_5c335283d91ec'),
(988, 134, 'logo-img-header', '44'),
(989, 134, '_logo-img-header', 'field_5c331c4969119'),
(990, 134, 'header-text', 'Creative Agency Template'),
(991, 134, '_header-text', 'field_5c331d847cfee'),
(992, 134, 'service-list_0_list-nmbr', '01'),
(993, 134, '_service-list_0_list-nmbr', 'field_5c331f8dfa326'),
(994, 134, 'service-list_0_list-hdr', 'Web Designing'),
(995, 134, '_service-list_0_list-hdr', 'field_5c331fcafa327'),
(996, 134, 'service-list_0_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(997, 134, '_service-list_0_list-txt', 'field_5c332002fa328'),
(998, 134, 'service-list_1_list-nmbr', '02'),
(999, 134, '_service-list_1_list-nmbr', 'field_5c331f8dfa326'),
(1000, 134, 'service-list_1_list-hdr', 'Photography'),
(1001, 134, '_service-list_1_list-hdr', 'field_5c331fcafa327'),
(1002, 134, 'service-list_1_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(1003, 134, '_service-list_1_list-txt', 'field_5c332002fa328'),
(1004, 134, 'service-list_2_list-nmbr', '03'),
(1005, 134, '_service-list_2_list-nmbr', 'field_5c331f8dfa326'),
(1006, 134, 'service-list_2_list-hdr', 'Art Direction'),
(1007, 134, '_service-list_2_list-hdr', 'field_5c331fcafa327'),
(1008, 134, 'service-list_2_list-txt', 'Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel'),
(1009, 134, '_service-list_2_list-txt', 'field_5c332002fa328'),
(1010, 134, 'service-list', '3'),
(1011, 134, '_service-list', 'field_5c331f35fa325'),
(1012, 134, 'header-about', 'About Company'),
(1013, 134, '_header-about', 'field_5c3323f446b21'),
(1014, 134, 'subheader-adout', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(1015, 134, '_subheader-adout', 'field_5c33243d46b22'),
(1016, 134, 'text-about', ''),
(1017, 134, '_text-about', 'field_5c33246946b23'),
(1018, 134, 'text-p1-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corpo commosequatur? Quis autem vel eum iure veniam, quis nostru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem quis nostru iure...'),
(1019, 134, '_text-p1-about', 'field_5c3326c1f07c4'),
(1020, 134, 'text-p2-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction doloru sequatur? Quis autem vel eum Quis autem vel eum iure veniam lorem ipsui lorem quis nostru iure.Ut enim ad minima veniam, quis nostrum exercitatio commosequatur? '),
(1021, 134, '_text-p2-about', 'field_5c3326f3f07c5'),
(1022, 134, 'text-p3-about', 'Ut enim ad minima veniam, quis nostrum exercitationem corporate loorem commosequatur? Quis autem vel eum iure veniam, quis nostruction dolor sequatur.'),
(1023, 134, '_text-p3-about', 'field_5c332707f07c6'),
(1024, 134, 'image-1-about', '66'),
(1025, 134, '_image-1-about', 'field_5c33272e2f33a'),
(1026, 134, 'image-2-about', '67'),
(1027, 134, '_image-2-about', 'field_5c33281b2f33b'),
(1028, 134, 'image-3-about', '68'),
(1029, 134, '_image-3-about', 'field_5c3328432f33c'),
(1030, 134, 'service-header', 'Our Services'),
(1031, 134, '_service-header', 'field_5c332b4f09dca'),
(1032, 134, 'service-subheader', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(1033, 134, '_service-subheader', 'field_5c332b7709dcb'),
(1034, 134, 'header-background-img', '74'),
(1035, 134, '_header-background-img', 'field_5c332e3eca9fd'),
(1036, 134, 'header-works', 'Our Portfolio'),
(1037, 134, '_header-works', 'field_5c3330b52fe1e'),
(1038, 134, 'subheader-works', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(1039, 134, '_subheader-works', 'field_5c3330d12fe1f'),
(1040, 134, 'filter-1-works', 'All'),
(1041, 134, '_filter-1-works', 'field_5c3334235a30e'),
(1042, 134, 'filter-2-works', 'Web Design'),
(1043, 134, '_filter-2-works', 'field_5c333cb15a30f'),
(1044, 134, 'filter-3-works', 'Art Direction'),
(1045, 134, '_filter-3-works', 'field_5c333cbd5a310'),
(1046, 134, 'filter-4-works', 'Creative'),
(1047, 134, '_filter-4-works', 'field_5c333cc35a311'),
(1048, 134, 'filter-5-works', 'WordPress'),
(1049, 134, '_filter-5-works', 'field_5c333cc95a312'),
(1050, 134, 'image-1-works', '103'),
(1051, 134, '_image-1-works', 'field_5c333d0c62cbd'),
(1052, 134, 'image-name-1-works', 'New Packaging'),
(1053, 134, '_image-name-1-works', 'field_5c333d3b62cbe'),
(1054, 134, 'image-2-works', '104'),
(1055, 134, '_image-2-works', 'field_5c333d4762cbf'),
(1056, 134, 'image-name-2-works', 'Healty Drinks'),
(1057, 134, '_image-name-2-works', 'field_5c333d5362cc0'),
(1058, 134, 'image-3-works', '105'),
(1059, 134, '_image-3-works', 'field_5c333d6a62cc1'),
(1060, 134, 'image-name-3-works', 'Smart Bottle'),
(1061, 134, '_image-name-3-works', 'field_5c333d8262cc2'),
(1062, 134, 'image-4-works', '106'),
(1063, 134, '_image-4-works', 'field_5c333d8f62cc3'),
(1064, 134, 'image-name-4-works', 'Stored Album'),
(1065, 134, '_image-name-4-works', 'field_5c333da162cc4'),
(1066, 134, 'image-5-works', '107'),
(1067, 134, '_image-5-works', 'field_5c333e966741a'),
(1068, 134, 'image-name-5-works', 'Shopping Bag'),
(1069, 134, '_image-name-5-works', 'field_5c333fd2af262'),
(1070, 134, 'image-6-works', '108'),
(1071, 134, '_image-6-works', 'field_5c33401d1c694'),
(1072, 134, 'image-name-6-works', 'Coffee Break'),
(1073, 134, '_image-name-6-works', 'field_5c3340401c695'),
(1074, 134, 'image-7-works', '109'),
(1075, 134, '_image-7-works', 'field_5c3340654ff12'),
(1076, 134, 'image-name-7-works', 'Clean Water'),
(1077, 134, '_image-name-7-works', 'field_5c3340844ff13'),
(1078, 134, 'image-8-works', '110'),
(1079, 134, '_image-8-works', 'field_5c3340bb7064b'),
(1080, 134, 'image-name-8-works', 'Total Refreshment'),
(1081, 134, '_image-name-8-works', 'field_5c3340dc7064c'),
(1082, 134, 'blog-title', 'Latest Articles'),
(1083, 134, '_blog-title', 'field_5c3344534e7b3'),
(1084, 134, 'blog-subtitle', 'Lorem ipsum dolor sit, consectet ipsum dolor sit'),
(1085, 134, '_blog-subtitle', 'field_5c3344714e7b4'),
(1086, 134, 'blog-list_0_blog-list-img', '119'),
(1087, 134, '_blog-list_0_blog-list-img', 'field_5c3344db9eed4'),
(1088, 134, 'blog-list_0_blog-list-header', 'Create any idea to make different'),
(1089, 134, '_blog-list_0_blog-list-header', 'field_5c33450e9eed5'),
(1090, 134, 'blog-list_0_blog-list-url', 'Go to article'),
(1091, 134, '_blog-list_0_blog-list-url', 'field_5c3345429eed6'),
(1092, 134, 'blog-list_1_blog-list-img', '120'),
(1093, 134, '_blog-list_1_blog-list-img', 'field_5c3344db9eed4'),
(1094, 134, 'blog-list_1_blog-list-header', 'Design unique as your passion'),
(1095, 134, '_blog-list_1_blog-list-header', 'field_5c33450e9eed5'),
(1096, 134, 'blog-list_1_blog-list-url', 'Go to article'),
(1097, 134, '_blog-list_1_blog-list-url', 'field_5c3345429eed6'),
(1098, 134, 'blog-list_2_blog-list-img', '121'),
(1099, 134, '_blog-list_2_blog-list-img', 'field_5c3344db9eed4'),
(1100, 134, 'blog-list_2_blog-list-header', 'Do hard work to be fast & successful'),
(1101, 134, '_blog-list_2_blog-list-header', 'field_5c33450e9eed5'),
(1102, 134, 'blog-list_2_blog-list-url', 'Go to article'),
(1103, 134, '_blog-list_2_blog-list-url', 'field_5c3345429eed6'),
(1104, 134, 'blog-list', '3'),
(1105, 134, '_blog-list', 'field_5c3344a59eed3'),
(1106, 134, 'butt-down-img', '124'),
(1107, 134, '_butt-down-img', 'field_5c334ff94736f'),
(1108, 134, 'phone-footer', 'Phone'),
(1109, 134, '_phone-footer', 'field_5c33517733b27'),
(1110, 134, 'phone-nbr-footer', '+ 123 - 456 -789, + 987 - 654 - 321'),
(1111, 134, '_phone-nbr-footer', 'field_5c3351ab33b28'),
(1112, 134, 'address-footer', 'Address'),
(1113, 134, '_address-footer', 'field_5c3351cb33b29'),
(1114, 134, 'address-txt-footer', 'RK road, United states of America'),
(1115, 134, '_address-txt-footer', 'field_5c33520133b2a'),
(1116, 134, 'e-mail-footer', 'E-mail'),
(1117, 134, '_e-mail-footer', 'field_5c33522933b2b'),
(1118, 134, 'e-mail-name-footer', 'carrbyagency@gmail.com'),
(1119, 134, '_e-mail-name-footer', 'field_5c33525133b2c'),
(1120, 134, 'copyright-footer', '&copy; 2018 - carrby.agency. Created by <a href=\"#\">WP ThemeBooster</a> All rights reserved.'),
(1121, 134, '_copyright-footer', 'field_5c335283d91ec');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-12-23 19:12:20', '2018-12-23 16:12:20', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2018-12-23 19:12:20', '2018-12-23 16:12:20', '', 0, 'http://localhost/startit/?p=1', 0, 'post', '', 1),
(2, 1, '2018-12-23 19:12:20', '2018-12-23 16:12:20', 'Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:\n\n<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>\n\n...или так:\n\n<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>\n\nПерейдите <a href=\"http://localhost/startit/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-12-23 19:12:20', '2018-12-23 16:12:20', '', 0, 'http://localhost/startit/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-12-23 19:12:20', '2018-12-23 16:12:20', '<h2>Кто мы</h2><p>Наш адрес сайта: http://localhost/startit.</p><h2>Какие персональные данные мы собираем и с какой целью</h2><h3>Комментарии</h3><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><h3>Медиафайлы</h3><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><h3>Формы контактов</h3><h3>Куки</h3><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><h3>Встраиваемое содержимое других вебсайтов</h3><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><h3>Веб-аналитика</h3><h2>С кем мы делимся вашими данными</h2><h2>Как долго мы храним ваши данные</h2><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><h2>Какие у вас права на ваши данные</h2><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><h2>Куда мы отправляем ваши данные</h2><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><h2>Ваша контактная информация</h2><h2>Дополнительная информация</h2><h3>Как мы защищаем ваши данные</h3><h3>Какие принимаются процедуры против взлома данных</h3><h3>От каких третьих сторон мы получаем данные</h3><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><h3>Требования к раскрытию отраслевых нормативных требований</h3>', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-12-23 19:12:20', '2018-12-23 16:12:20', '', 0, 'http://localhost/startit/?page_id=3', 0, 'page', '', 0),
(5, 1, '2019-01-06 17:17:13', '0000-00-00 00:00:00', '', 'Главная', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-01-06 17:17:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/startit/?p=5', 1, 'nav_menu_item', '', 0),
(32, 1, '2019-01-06 18:01:24', '2019-01-06 15:01:24', 'a:7:{s:8:\"location\";a:1:{i:0;a:2:{i:0;a:3:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:17:\"category:services\";}i:1;a:3:{s:5:\"param\";s:12:\"current_user\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:9:\"logged_in\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Our Services', 'our-services', 'trash', 'closed', 'closed', '', 'group_5c32172aa5d9d__trashed', '', '', '2019-01-07 12:30:14', '2019-01-07 09:30:14', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=32', 0, 'acf-field-group', '', 0),
(33, 1, '2019-01-06 18:01:24', '2019-01-06 15:01:24', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Our Services', 'our_services_title', 'trash', 'closed', 'closed', '', 'field_5c32176f84997__trashed', '', '', '2019-01-07 12:30:14', '2019-01-07 09:30:14', '', 32, 'http://localhost/startit/?post_type=acf-field&#038;p=33', 0, 'acf-field', '', 0),
(34, 1, '2019-01-06 18:33:42', '2019-01-06 15:33:42', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-01-06 18:33:42', '2019-01-06 15:33:42', '', 0, 'http://localhost/startit/?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2019-01-06 18:33:42', '2019-01-06 15:33:42', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2019-01-06 18:33:42', '2019-01-06 15:33:42', '', 0, 'http://localhost/startit/?p=35', 2, 'nav_menu_item', '', 0),
(36, 1, '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 0, 'http://localhost/startit/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 'Portfolio', '', 'publish', 'closed', 'closed', '', 'portfolio', '', '', '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 0, 'http://localhost/startit/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 0, 'http://localhost/startit/?p=38', 5, 'nav_menu_item', '', 0),
(39, 1, '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-01-06 18:33:43', '2019-01-06 15:33:43', '', 0, 'http://localhost/startit/?p=39', 6, 'nav_menu_item', '', 0),
(40, 1, '2019-01-07 12:23:07', '2019-01-07 09:23:07', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2019-01-07 16:24:14', '2019-01-07 13:24:14', '', 0, 'http://localhost/startit/?page_id=40', 0, 'page', '', 0),
(41, 1, '2019-01-07 12:23:07', '2019-01-07 09:23:07', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 12:23:07', '2019-01-07 09:23:07', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2019-01-07 12:31:34', '2019-01-07 09:31:34', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Header', 'header', 'publish', 'closed', 'closed', '', 'group_5c331c2d119b3', '', '', '2019-01-07 16:12:12', '2019-01-07 13:12:12', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=42', 0, 'acf-field-group', '', 0),
(43, 1, '2019-01-07 12:31:34', '2019-01-07 09:31:34', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Логотип сайта', 'logo-img-header', 'publish', 'closed', 'closed', '', 'field_5c331c4969119', '', '', '2019-01-07 12:35:14', '2019-01-07 09:35:14', '', 42, 'http://localhost/startit/?post_type=acf-field&#038;p=43', 0, 'acf-field', '', 0),
(44, 1, '2019-01-07 12:32:45', '2019-01-07 09:32:45', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-01-07 12:32:45', '2019-01-07 09:32:45', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/logo.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2019-01-07 12:32:53', '2019-01-07 09:32:53', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 12:32:53', '2019-01-07 09:32:53', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2019-01-07 12:37:25', '2019-01-07 09:37:25', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст шапки', 'header-text', 'publish', 'closed', 'closed', '', 'field_5c331d847cfee', '', '', '2019-01-07 12:37:25', '2019-01-07 09:37:25', '', 42, 'http://localhost/startit/?post_type=acf-field&p=46', 1, 'acf-field', '', 0),
(47, 1, '2019-01-07 12:38:15', '2019-01-07 09:38:15', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 12:38:15', '2019-01-07 09:38:15', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2019-01-07 12:43:14', '2019-01-07 09:43:14', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Services', 'services', 'publish', 'closed', 'closed', '', 'group_5c331f1c5757e', '', '', '2019-01-07 13:36:35', '2019-01-07 10:36:35', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=48', 0, 'acf-field-group', '', 0),
(49, 1, '2019-01-07 12:47:47', '2019-01-07 09:47:47', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Список сервисов', 'service-list', 'publish', 'closed', 'closed', '', 'field_5c331f35fa325', '', '', '2019-01-07 12:47:47', '2019-01-07 09:47:47', '', 48, 'http://localhost/startit/?post_type=acf-field&p=49', 0, 'acf-field', '', 0),
(50, 1, '2019-01-07 12:47:47', '2019-01-07 09:47:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Номер списка', 'list-nmbr', 'publish', 'closed', 'closed', '', 'field_5c331f8dfa326', '', '', '2019-01-07 12:47:47', '2019-01-07 09:47:47', '', 49, 'http://localhost/startit/?post_type=acf-field&p=50', 0, 'acf-field', '', 0),
(51, 1, '2019-01-07 12:47:47', '2019-01-07 09:47:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок пункта', 'list-hdr', 'publish', 'closed', 'closed', '', 'field_5c331fcafa327', '', '', '2019-01-07 12:47:47', '2019-01-07 09:47:47', '', 49, 'http://localhost/startit/?post_type=acf-field&p=51', 1, 'acf-field', '', 0),
(52, 1, '2019-01-07 12:47:47', '2019-01-07 09:47:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст пункта', 'list-txt', 'publish', 'closed', 'closed', '', 'field_5c332002fa328', '', '', '2019-01-07 12:47:47', '2019-01-07 09:47:47', '', 49, 'http://localhost/startit/?post_type=acf-field&p=52', 2, 'acf-field', '', 0),
(53, 1, '2019-01-07 12:49:19', '2019-01-07 09:49:19', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 12:49:19', '2019-01-07 09:49:19', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2019-01-07 13:08:41', '2019-01-07 10:08:41', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'About', 'about', 'publish', 'closed', 'closed', '', 'group_5c3323e371ecb', '', '', '2019-01-07 13:22:21', '2019-01-07 10:22:21', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=54', 0, 'acf-field-group', '', 0),
(55, 1, '2019-01-07 13:08:41', '2019-01-07 10:08:41', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок поля', 'header-about', 'publish', 'closed', 'closed', '', 'field_5c3323f446b21', '', '', '2019-01-07 13:08:41', '2019-01-07 10:08:41', '', 54, 'http://localhost/startit/?post_type=acf-field&p=55', 0, 'acf-field', '', 0),
(56, 1, '2019-01-07 13:08:41', '2019-01-07 10:08:41', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Подзаголовок поля', 'subheader-adout', 'publish', 'closed', 'closed', '', 'field_5c33243d46b22', '', '', '2019-01-07 13:08:41', '2019-01-07 10:08:41', '', 54, 'http://localhost/startit/?post_type=acf-field&p=56', 1, 'acf-field', '', 0),
(59, 1, '2019-01-07 13:15:05', '2019-01-07 10:15:05', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 13:15:05', '2019-01-07 10:15:05', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2019-01-07 13:17:00', '2019-01-07 10:17:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст поля p1', 'text-p1-about', 'publish', 'closed', 'closed', '', 'field_5c3326c1f07c4', '', '', '2019-01-07 13:17:00', '2019-01-07 10:17:00', '', 54, 'http://localhost/startit/?post_type=acf-field&p=60', 2, 'acf-field', '', 0),
(61, 1, '2019-01-07 13:17:00', '2019-01-07 10:17:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст поля p2', 'text-p2-about', 'publish', 'closed', 'closed', '', 'field_5c3326f3f07c5', '', '', '2019-01-07 13:17:00', '2019-01-07 10:17:00', '', 54, 'http://localhost/startit/?post_type=acf-field&p=61', 3, 'acf-field', '', 0),
(62, 1, '2019-01-07 13:17:00', '2019-01-07 10:17:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст поля p2', 'text-p3-about', 'publish', 'closed', 'closed', '', 'field_5c332707f07c6', '', '', '2019-01-07 13:17:00', '2019-01-07 10:17:00', '', 54, 'http://localhost/startit/?post_type=acf-field&p=62', 4, 'acf-field', '', 0),
(63, 1, '2019-01-07 13:22:21', '2019-01-07 10:22:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 1', 'image-1-about', 'publish', 'closed', 'closed', '', 'field_5c33272e2f33a', '', '', '2019-01-07 13:22:21', '2019-01-07 10:22:21', '', 54, 'http://localhost/startit/?post_type=acf-field&p=63', 5, 'acf-field', '', 0),
(64, 1, '2019-01-07 13:22:21', '2019-01-07 10:22:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 2', 'image-2-about', 'publish', 'closed', 'closed', '', 'field_5c33281b2f33b', '', '', '2019-01-07 13:22:21', '2019-01-07 10:22:21', '', 54, 'http://localhost/startit/?post_type=acf-field&p=64', 6, 'acf-field', '', 0),
(65, 1, '2019-01-07 13:22:21', '2019-01-07 10:22:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 3', 'image-3-about', 'publish', 'closed', 'closed', '', 'field_5c3328432f33c', '', '', '2019-01-07 13:22:21', '2019-01-07 10:22:21', '', 54, 'http://localhost/startit/?post_type=acf-field&p=65', 7, 'acf-field', '', 0),
(66, 1, '2019-01-07 13:23:56', '2019-01-07 10:23:56', '', 'img1', '', 'inherit', 'open', 'closed', '', 'img1', '', '', '2019-01-07 13:23:56', '2019-01-07 10:23:56', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/img1.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2019-01-07 13:24:09', '2019-01-07 10:24:09', '', 'img2', '', 'inherit', 'open', 'closed', '', 'img2', '', '', '2019-01-07 13:24:09', '2019-01-07 10:24:09', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/img2.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2019-01-07 13:24:18', '2019-01-07 10:24:18', '', 'img3', '', 'inherit', 'open', 'closed', '', 'img3', '', '', '2019-01-07 13:24:18', '2019-01-07 10:24:18', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/img3.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2019-01-07 13:27:17', '2019-01-07 10:27:17', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 13:27:17', '2019-01-07 10:27:17', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2019-01-07 13:36:35', '2019-01-07 10:36:35', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок поля', 'service-header', 'publish', 'closed', 'closed', '', 'field_5c332b4f09dca', '', '', '2019-01-07 13:36:35', '2019-01-07 10:36:35', '', 48, 'http://localhost/startit/?post_type=acf-field&p=70', 1, 'acf-field', '', 0),
(71, 1, '2019-01-07 13:36:35', '2019-01-07 10:36:35', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Подзаголовок поля', 'service-subheader', 'publish', 'closed', 'closed', '', 'field_5c332b7709dcb', '', '', '2019-01-07 13:36:35', '2019-01-07 10:36:35', '', 48, 'http://localhost/startit/?post_type=acf-field&p=71', 2, 'acf-field', '', 0),
(72, 1, '2019-01-07 13:38:17', '2019-01-07 10:38:17', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 13:38:17', '2019-01-07 10:38:17', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2019-01-07 13:48:41', '2019-01-07 10:48:41', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Фон шапки', 'header-background-img', 'publish', 'closed', 'closed', '', 'field_5c332e3eca9fd', '', '', '2019-01-07 13:48:41', '2019-01-07 10:48:41', '', 42, 'http://localhost/startit/?post_type=acf-field&p=73', 2, 'acf-field', '', 0),
(74, 1, '2019-01-07 13:49:25', '2019-01-07 10:49:25', '', 'slider-bg1', '', 'inherit', 'open', 'closed', '', 'slider-bg1', '', '', '2019-01-07 13:49:25', '2019-01-07 10:49:25', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/slider-bg1.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2019-01-07 13:49:46', '2019-01-07 10:49:46', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 13:49:46', '2019-01-07 10:49:46', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2019-01-07 13:58:53', '2019-01-07 10:58:53', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Works', 'works', 'publish', 'closed', 'closed', '', 'group_5c3330a2be5b4', '', '', '2019-01-07 15:07:17', '2019-01-07 12:07:17', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(77, 1, '2019-01-07 13:58:54', '2019-01-07 10:58:54', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок поля', 'header-works', 'publish', 'closed', 'closed', '', 'field_5c3330b52fe1e', '', '', '2019-01-07 13:58:54', '2019-01-07 10:58:54', '', 76, 'http://localhost/startit/?post_type=acf-field&p=77', 0, 'acf-field', '', 0),
(78, 1, '2019-01-07 13:58:54', '2019-01-07 10:58:54', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Подзаголовок поля', 'subheader-works', 'publish', 'closed', 'closed', '', 'field_5c3330d12fe1f', '', '', '2019-01-07 13:58:54', '2019-01-07 10:58:54', '', 76, 'http://localhost/startit/?post_type=acf-field&p=78', 1, 'acf-field', '', 0),
(79, 1, '2019-01-07 14:04:42', '2019-01-07 11:04:42', '', 'favicon', '', 'inherit', 'open', 'closed', '', 'favicon', '', '', '2019-01-07 14:04:42', '2019-01-07 11:04:42', '', 0, 'http://localhost/startit/wp-content/uploads/2019/01/favicon.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2019-01-07 14:04:53', '2019-01-07 11:04:53', '{\n    \"site_icon\": {\n        \"value\": 79,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-01-07 11:04:53\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b0c5cc57-37da-4e78-be42-c07814be33c9', '', '', '2019-01-07 14:04:53', '2019-01-07 11:04:53', '', 0, 'http://localhost/startit/2019/01/07/b0c5cc57-37da-4e78-be42-c07814be33c9/', 0, 'customize_changeset', '', 0),
(81, 1, '2019-01-07 14:07:14', '2019-01-07 11:07:14', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 14:07:14', '2019-01-07 11:07:14', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2019-01-07 14:50:30', '2019-01-07 11:50:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Фильтр 1', 'filter-1-works', 'publish', 'closed', 'closed', '', 'field_5c3334235a30e', '', '', '2019-01-07 14:50:30', '2019-01-07 11:50:30', '', 76, 'http://localhost/startit/?post_type=acf-field&p=82', 2, 'acf-field', '', 0),
(83, 1, '2019-01-07 14:50:30', '2019-01-07 11:50:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Фильтр 2', 'filter-2-works', 'publish', 'closed', 'closed', '', 'field_5c333cb15a30f', '', '', '2019-01-07 14:50:30', '2019-01-07 11:50:30', '', 76, 'http://localhost/startit/?post_type=acf-field&p=83', 3, 'acf-field', '', 0),
(84, 1, '2019-01-07 14:50:30', '2019-01-07 11:50:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Фильтр 3', 'filter-3-works', 'publish', 'closed', 'closed', '', 'field_5c333cbd5a310', '', '', '2019-01-07 14:50:30', '2019-01-07 11:50:30', '', 76, 'http://localhost/startit/?post_type=acf-field&p=84', 4, 'acf-field', '', 0),
(85, 1, '2019-01-07 14:50:30', '2019-01-07 11:50:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Фильтр 4', 'filter-4-works', 'publish', 'closed', 'closed', '', 'field_5c333cc35a311', '', '', '2019-01-07 14:50:30', '2019-01-07 11:50:30', '', 76, 'http://localhost/startit/?post_type=acf-field&p=85', 5, 'acf-field', '', 0),
(86, 1, '2019-01-07 14:50:30', '2019-01-07 11:50:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Фильтр 5', 'filter-5-works', 'publish', 'closed', 'closed', '', 'field_5c333cc95a312', '', '', '2019-01-07 14:50:30', '2019-01-07 11:50:30', '', 76, 'http://localhost/startit/?post_type=acf-field&p=86', 6, 'acf-field', '', 0),
(87, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 1', 'image-1-works', 'publish', 'closed', 'closed', '', 'field_5c333d0c62cbd', '', '', '2019-01-07 14:54:37', '2019-01-07 11:54:37', '', 76, 'http://localhost/startit/?post_type=acf-field&p=87', 7, 'acf-field', '', 0),
(88, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 1', 'image-name-1-works', 'publish', 'closed', 'closed', '', 'field_5c333d3b62cbe', '', '', '2019-01-07 14:59:44', '2019-01-07 11:59:44', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=88', 8, 'acf-field', '', 0),
(89, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 2', 'image-2-works', 'publish', 'closed', 'closed', '', 'field_5c333d4762cbf', '', '', '2019-01-07 14:59:44', '2019-01-07 11:59:44', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=89', 9, 'acf-field', '', 0),
(90, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 2', 'image-name-2-works', 'publish', 'closed', 'closed', '', 'field_5c333d5362cc0', '', '', '2019-01-07 14:59:44', '2019-01-07 11:59:44', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=90', 10, 'acf-field', '', 0),
(91, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 3', 'image-3-works', 'publish', 'closed', 'closed', '', 'field_5c333d6a62cc1', '', '', '2019-01-07 15:00:09', '2019-01-07 12:00:09', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=91', 11, 'acf-field', '', 0),
(92, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 3', 'image-name-3-works', 'publish', 'closed', 'closed', '', 'field_5c333d8262cc2', '', '', '2019-01-07 15:00:40', '2019-01-07 12:00:40', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=92', 12, 'acf-field', '', 0),
(93, 1, '2019-01-07 14:54:37', '2019-01-07 11:54:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 4', 'image-4-works', 'publish', 'closed', 'closed', '', 'field_5c333d8f62cc3', '', '', '2019-01-07 15:01:44', '2019-01-07 12:01:44', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=93', 13, 'acf-field', '', 0),
(94, 1, '2019-01-07 14:54:38', '2019-01-07 11:54:38', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 4', 'image-name-4-works', 'publish', 'closed', 'closed', '', 'field_5c333da162cc4', '', '', '2019-01-07 15:01:44', '2019-01-07 12:01:44', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=94', 14, 'acf-field', '', 0),
(95, 1, '2019-01-07 14:59:44', '2019-01-07 11:59:44', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 5', 'image-5-works', 'publish', 'closed', 'closed', '', 'field_5c333e966741a', '', '', '2019-01-07 15:03:23', '2019-01-07 12:03:23', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=95', 15, 'acf-field', '', 0),
(96, 1, '2019-01-07 15:03:23', '2019-01-07 12:03:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 5', 'image-name-5-works', 'publish', 'closed', 'closed', '', 'field_5c333fd2af262', '', '', '2019-01-07 15:03:23', '2019-01-07 12:03:23', '', 76, 'http://localhost/startit/?post_type=acf-field&p=96', 16, 'acf-field', '', 0),
(97, 1, '2019-01-07 15:04:44', '2019-01-07 12:04:44', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 6', 'image-6-works', 'publish', 'closed', 'closed', '', 'field_5c33401d1c694', '', '', '2019-01-07 15:04:44', '2019-01-07 12:04:44', '', 76, 'http://localhost/startit/?post_type=acf-field&p=97', 17, 'acf-field', '', 0),
(98, 1, '2019-01-07 15:04:44', '2019-01-07 12:04:44', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 6', 'image-name-6-works', 'publish', 'closed', 'closed', '', 'field_5c3340401c695', '', '', '2019-01-07 15:04:44', '2019-01-07 12:04:44', '', 76, 'http://localhost/startit/?post_type=acf-field&p=98', 18, 'acf-field', '', 0),
(99, 1, '2019-01-07 15:05:53', '2019-01-07 12:05:53', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 7', 'image-7-works', 'publish', 'closed', 'closed', '', 'field_5c3340654ff12', '', '', '2019-01-07 15:05:53', '2019-01-07 12:05:53', '', 76, 'http://localhost/startit/?post_type=acf-field&p=99', 19, 'acf-field', '', 0),
(100, 1, '2019-01-07 15:05:53', '2019-01-07 12:05:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 7', 'image-name-7-works', 'publish', 'closed', 'closed', '', 'field_5c3340844ff13', '', '', '2019-01-07 15:06:11', '2019-01-07 12:06:11', '', 76, 'http://localhost/startit/?post_type=acf-field&#038;p=100', 20, 'acf-field', '', 0),
(101, 1, '2019-01-07 15:07:17', '2019-01-07 12:07:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение 8', 'image-8-works', 'publish', 'closed', 'closed', '', 'field_5c3340bb7064b', '', '', '2019-01-07 15:07:17', '2019-01-07 12:07:17', '', 76, 'http://localhost/startit/?post_type=acf-field&p=101', 21, 'acf-field', '', 0),
(102, 1, '2019-01-07 15:07:17', '2019-01-07 12:07:17', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Название 8', 'image-name-8-works', 'publish', 'closed', 'closed', '', 'field_5c3340dc7064c', '', '', '2019-01-07 15:07:17', '2019-01-07 12:07:17', '', 76, 'http://localhost/startit/?post_type=acf-field&p=102', 22, 'acf-field', '', 0),
(103, 1, '2019-01-07 15:09:45', '2019-01-07 12:09:45', '', 'project-1', '', 'inherit', 'open', 'closed', '', 'project-1', '', '', '2019-01-07 15:09:45', '2019-01-07 12:09:45', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2019-01-07 15:09:46', '2019-01-07 12:09:46', '', 'project-2', '', 'inherit', 'open', 'closed', '', 'project-2', '', '', '2019-01-07 15:09:46', '2019-01-07 12:09:46', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 1, '2019-01-07 15:09:48', '2019-01-07 12:09:48', '', 'project-3', '', 'inherit', 'open', 'closed', '', 'project-3', '', '', '2019-01-07 15:09:48', '2019-01-07 12:09:48', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2019-01-07 15:09:49', '2019-01-07 12:09:49', '', 'project-4', '', 'inherit', 'open', 'closed', '', 'project-4', '', '', '2019-01-07 15:09:49', '2019-01-07 12:09:49', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2019-01-07 15:09:50', '2019-01-07 12:09:50', '', 'project-5', '', 'inherit', 'open', 'closed', '', 'project-5', '', '', '2019-01-07 15:09:50', '2019-01-07 12:09:50', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2019-01-07 15:09:51', '2019-01-07 12:09:51', '', 'project-6', '', 'inherit', 'open', 'closed', '', 'project-6', '', '', '2019-01-07 15:09:51', '2019-01-07 12:09:51', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(109, 1, '2019-01-07 15:09:52', '2019-01-07 12:09:52', '', 'project-7', '', 'inherit', 'open', 'closed', '', 'project-7', '', '', '2019-01-07 15:09:52', '2019-01-07 12:09:52', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(110, 1, '2019-01-07 15:09:53', '2019-01-07 12:09:53', '', 'project-8', '', 'inherit', 'open', 'closed', '', 'project-8', '', '', '2019-01-07 15:09:53', '2019-01-07 12:09:53', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/project-8.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 1, '2019-01-07 15:11:16', '2019-01-07 12:11:16', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 15:11:16', '2019-01-07 12:11:16', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2019-01-07 15:22:57', '2019-01-07 12:22:57', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Blog', 'blog', 'publish', 'closed', 'closed', '', 'group_5c334445e3bb7', '', '', '2019-01-07 15:26:40', '2019-01-07 12:26:40', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=112', 0, 'acf-field-group', '', 0),
(113, 1, '2019-01-07 15:22:57', '2019-01-07 12:22:57', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок поля', 'blog-title', 'publish', 'closed', 'closed', '', 'field_5c3344534e7b3', '', '', '2019-01-07 15:22:57', '2019-01-07 12:22:57', '', 112, 'http://localhost/startit/?post_type=acf-field&p=113', 0, 'acf-field', '', 0),
(114, 1, '2019-01-07 15:22:57', '2019-01-07 12:22:57', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Подзаголовок поля', 'blog-subtitle', 'publish', 'closed', 'closed', '', 'field_5c3344714e7b4', '', '', '2019-01-07 15:22:57', '2019-01-07 12:22:57', '', 112, 'http://localhost/startit/?post_type=acf-field&p=114', 1, 'acf-field', '', 0),
(115, 1, '2019-01-07 15:26:21', '2019-01-07 12:26:21', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Список', 'blog-list', 'publish', 'closed', 'closed', '', 'field_5c3344a59eed3', '', '', '2019-01-07 15:26:21', '2019-01-07 12:26:21', '', 112, 'http://localhost/startit/?post_type=acf-field&p=115', 2, 'acf-field', '', 0),
(116, 1, '2019-01-07 15:26:21', '2019-01-07 12:26:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Изображение', 'blog-list-img', 'publish', 'closed', 'closed', '', 'field_5c3344db9eed4', '', '', '2019-01-07 15:26:21', '2019-01-07 12:26:21', '', 115, 'http://localhost/startit/?post_type=acf-field&p=116', 0, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(117, 1, '2019-01-07 15:26:21', '2019-01-07 12:26:21', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Заголовок', 'blog-list-header', 'publish', 'closed', 'closed', '', 'field_5c33450e9eed5', '', '', '2019-01-07 15:26:21', '2019-01-07 12:26:21', '', 115, 'http://localhost/startit/?post_type=acf-field&p=117', 1, 'acf-field', '', 0),
(118, 1, '2019-01-07 15:26:21', '2019-01-07 12:26:21', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Далее', 'blog-list-url', 'publish', 'closed', 'closed', '', 'field_5c3345429eed6', '', '', '2019-01-07 15:26:21', '2019-01-07 12:26:21', '', 115, 'http://localhost/startit/?post_type=acf-field&p=118', 2, 'acf-field', '', 0),
(119, 1, '2019-01-07 15:28:03', '2019-01-07 12:28:03', '', 'blog-1', '', 'inherit', 'open', 'closed', '', 'blog-1', '', '', '2019-01-07 15:28:03', '2019-01-07 12:28:03', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/blog-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2019-01-07 15:28:04', '2019-01-07 12:28:04', '', 'blog-2', '', 'inherit', 'open', 'closed', '', 'blog-2', '', '', '2019-01-07 15:28:04', '2019-01-07 12:28:04', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/blog-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(121, 1, '2019-01-07 15:28:05', '2019-01-07 12:28:05', '', 'blog-3', '', 'inherit', 'open', 'closed', '', 'blog-3', '', '', '2019-01-07 15:28:05', '2019-01-07 12:28:05', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/blog-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(122, 1, '2019-01-07 15:28:51', '2019-01-07 12:28:51', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 15:28:51', '2019-01-07 12:28:51', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2019-01-07 16:12:12', '2019-01-07 13:12:12', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Кнопка вниз', 'butt-down-img', 'publish', 'closed', 'closed', '', 'field_5c334ff94736f', '', '', '2019-01-07 16:12:12', '2019-01-07 13:12:12', '', 42, 'http://localhost/startit/?post_type=acf-field&p=123', 3, 'acf-field', '', 0),
(124, 1, '2019-01-07 16:12:47', '2019-01-07 13:12:47', '', 'shape1', '', 'inherit', 'open', 'closed', '', 'shape1', '', '', '2019-01-07 16:12:47', '2019-01-07 13:12:47', '', 40, 'http://localhost/startit/wp-content/uploads/2019/01/shape1.png', 0, 'attachment', 'image/png', 0),
(125, 1, '2019-01-07 16:13:05', '2019-01-07 13:13:05', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 16:13:05', '2019-01-07 13:13:05', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2019-01-07 16:17:39', '2019-01-07 13:17:39', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"40\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Footer', 'footer', 'publish', 'closed', 'closed', '', 'group_5c33515f156c6', '', '', '2019-01-07 16:22:42', '2019-01-07 13:22:42', '', 0, 'http://localhost/startit/?post_type=acf-field-group&#038;p=126', 0, 'acf-field-group', '', 0),
(127, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Телефон', 'phone-footer', 'publish', 'closed', 'closed', '', 'field_5c33517733b27', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=127', 0, 'acf-field', '', 0),
(128, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Номер телефона', 'phone-nbr-footer', 'publish', 'closed', 'closed', '', 'field_5c3351ab33b28', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=128', 1, 'acf-field', '', 0),
(129, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Адрес', 'address-footer', 'publish', 'closed', 'closed', '', 'field_5c3351cb33b29', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=129', 2, 'acf-field', '', 0),
(130, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Текст адреса', 'address-txt-footer', 'publish', 'closed', 'closed', '', 'field_5c33520133b2a', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=130', 3, 'acf-field', '', 0),
(131, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'E-Mail', 'e-mail-footer', 'publish', 'closed', 'closed', '', 'field_5c33522933b2b', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=131', 4, 'acf-field', '', 0),
(132, 1, '2019-01-07 16:22:06', '2019-01-07 13:22:06', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Адресс E-Mail', 'e-mail-name-footer', 'publish', 'closed', 'closed', '', 'field_5c33525133b2c', '', '', '2019-01-07 16:22:06', '2019-01-07 13:22:06', '', 126, 'http://localhost/startit/?post_type=acf-field&p=132', 5, 'acf-field', '', 0),
(133, 1, '2019-01-07 16:22:42', '2019-01-07 13:22:42', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Copyright', 'copyright-footer', 'publish', 'closed', 'closed', '', 'field_5c335283d91ec', '', '', '2019-01-07 16:22:42', '2019-01-07 13:22:42', '', 126, 'http://localhost/startit/?post_type=acf-field&p=133', 6, 'acf-field', '', 0),
(134, 1, '2019-01-07 16:24:14', '2019-01-07 13:24:14', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2019-01-07 16:24:14', '2019-01-07 13:24:14', '', 40, 'http://localhost/startit/2019/01/07/40-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Главное меню', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%be%d0%b5-%d0%bc%d0%b5%d0%bd%d1%8e', 0),
(3, 'Home', 'home', 0),
(4, 'Services', 'services', 0),
(5, 'About Us', 'about-us', 0),
(6, 'Portfolio', 'portfolio', 0),
(7, 'Blog', 'blog', 0),
(8, 'Contact', 'contact', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(34, 2, 0),
(35, 2, 0),
(36, 2, 0),
(37, 2, 0),
(38, 2, 0),
(39, 2, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 6),
(3, 3, 'category', '', 0, 0),
(4, 4, 'category', '', 0, 0),
(5, 5, 'category', '', 0, 0),
(6, 6, 'category', '', 0, 0),
(7, 7, 'category', '', 0, 0),
(8, 8, 'category', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"563ccec66514ed4c363dbf370e29eacce89026846fe1e694adbc4bc8af545ab1\";a:4:{s:10:\"expiration\";i:1546956337;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0\";s:5:\"login\";i:1546783537;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(20, 1, 'nav_menu_recently_edited', '2'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1546853569');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B0AGwC66EGilHPTUdOWita3P0gGbn6.', 'admin', 'steell.overseer@gmail.com', '', '2018-12-23 16:12:20', '', 0, 'admin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Индексы таблицы `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Индексы таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT для таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1122;

--
-- AUTO_INCREMENT для таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT для таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
