 
            <footer id="footer" class="footer">
            <div class="footer-bottom">
                <div class="container">
                    <div class="copyright">
                        <p> &copy; 2018 - carrby.agency. Created by <a href="#">WP ThemeBooster</a> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </footer>

  <!-- All JavaScript Files
        ================================================== -->
        <script src="<?php echo get_template_directory_uri() ?>/js/jquery-3.2.1.min.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/bootstrap.min.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/jquery.mixitup.min.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/jquery.fancybox.min.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/owl.carousel.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/typed.min.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/menu.js"></script>
        <script src="<?php echo get_template_directory_uri() ?>/js/custom.js"></script>

    </body>
</html>
