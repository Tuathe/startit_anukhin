<!DOCTYPE html>
<html lang="zxx">
    <head>
        <!-- Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="description" content="Carrby - Agency Template">
        <meta name="author" content="">

        <!-- Page Title -->
        <title>Carrby - Agency Template</title>

        <!-- Favicon and Touch Icons -->
        <link href="<?php echo get_template_directory_uri() ?>/images/favicon.png" rel="shortcut icon" type="image/png">

        <!-- Lead Style -->
        <link href="<?php echo get_stylesheet_directory_uri() ?>/css/style.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
        

    </head>

    <body>
            <header id="header" class="header">
            <div class="navigation">
                <div class="container">
                    <nav id="flexmenu">
                        <div class="logo">
                            <a href="index.php"><img src="<?php echo get_template_directory_uri() ?>/images/logo.png" alt="logo"></a>
                        </div>
                        <div class="nav-inner">
                            <div id="mobile-toggle" class="mobile-btn"></div>
                            <ul class="main-menu">
                                <li class="menu-item"><a class="active" href="#slider">Home</a></li>
                                <li class="menu-item"><a href="#services">Services</a></li>
                                <li class="menu-item"><a href="#about">About Us</a></li>
                                <li class="menu-item"><a href="#works">Portfolio</a></li>
                                <li class="menu-item"><a href="#blog">Blog</a></li>
                                <li class="menu-item"><a href="#contact">Contact</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>