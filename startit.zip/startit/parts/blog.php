          <section id="blog" class="blog">
                <div class="container">
                    <div class="section-title">
                        <h2>Latest Articles</h2>
                        <p>Lorem ipsum dolor sit, consectet ipsum dolor sit</p>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="blog_post">
                                <div class="post_img">
                                    <a href="<?php echo get_stylesheet_directory_uri() ?>/index.html#"><img src="<?php echo get_stylesheet_directory_uri() ?>/images/blog/blog-1.jpg" alt="img"></a>
                                </div>
                                <div class="post_content">
                                    <div class="post_header">
                                        <h2 class="post_title"><a href="#">Create any idea to make different</a></h2>
                                        <div class="read_more"><a href="#">Go to article</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <div class="blog_post">
                                <div class="post_img">
                                    <a href="#"><img src="<?php echo get_stylesheet_directory_uri() ?>/images/blog/blog-2.jpg" alt="img"></a>
                                </div>
                                <div class="post_content">
                                    <div class="post_header">
                                        <h2 class="post_title"><a href="#">Design unique as your passion</a></h2>
                                        <div class="read_more"><a href="#">Go to article</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <div class="blog_post">
                                <div class="post_img">
                                    <a href="#"><img src="<?php echo get_stylesheet_directory_uri() ?>/images/blog/blog-3.jpg" alt="img"></a>
                                </div>
                                <div class="post_content">
                                    <div class="post_header">
                                        <h2 class="post_title"><a href="#">Do hard work to be fast & successful</a></h2>
                                        <div class="read_more"><a href="#">Go to article</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>