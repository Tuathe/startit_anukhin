          <section id="services" class="services pt-10">
                <div class="container">
                    <div class="section-title">
                        <h2>Our Services</h2>
                        <p>Lorem ipsum dolor sit, consectet ipsum dolor sit</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="servicebox">
                                <div class="srv_desc">
                                    <h5 class="count">01</h5>
                                    <h4><a href="#">Web Designing</a></h4>
                                    <p>Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="servicebox">
                                <div class="srv_desc">
                                    <h5 class="count">02</h5>
                                    <h4><a href="#">Photography</a></h4>
                                    <p>Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="servicebox">
                                <div class="srv_desc">
                                    <h5 class="count">03</h5>
                                    <h4><a href="#">Art Direction</a></h4>
                                    <p>Ut enim ad minima veniam, quis nostr um exercitationem corporate loorem commosequatur? Quis autem vel</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
